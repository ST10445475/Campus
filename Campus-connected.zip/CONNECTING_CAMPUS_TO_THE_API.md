# Connecting Campus (Android) to WeLoveCampusAPI + the Azure SQL database

This bundle contains both projects, unchanged except for the small set of edits below,
which is everything needed to make the Android app talk to the real API and database
instead of its built-in mock data.

## What was changed

### 1. `WeLoveCampusAPI/src/main/kotlin/CampusAppRouting.kt` — **new file**
Adds the three HTTP endpoints the Android app already expects (it was written against
these routes, but the API never implemented them):

- `GET /api/announcements?category=` → list of announcements
- `GET /api/events` → list of events
- `POST /api/notifications/register` → save a device's push-notification token

It reuses the **same Azure SQL database and the same `Announcements`/`Events` tables**
already defined in `AnnouncementService.kt` / `EventService.kt`, and adds one new small
table (`DeviceRegistrations`) purely to store push tokens, since nothing like that
existed yet. No existing file's logic was modified — this is a new, additive module.

Because the database's `Announcement`/`Event` tables don't store the exact fields the
Android app expects (there's no `sender`, `category`, or "posted at" timestamp), the
file derives reasonable values from what does exist and explains each choice in a
comment block at the top of the file. If you'd rather the database carry those fields
directly, that's a one-line change described there.

### 2. `WeLoveCampusAPI/src/main/resources/application.conf`
One line added to the `modules` list so Ktor loads the new file above. Nothing else in
this file changed.

### 3. `Campus-master/app/.../AppConfig.kt`
`USE_MOCK` flipped from `true` to `false`, and `BASE_URL` set to
`http://10.0.2.2:8080/` (the Android emulator's alias for your computer's localhost),
so the app calls the real API. Comments explain how to switch this to a LAN IP for a
physical device, or to your production HTTPS URL once deployed.

### 4. `Campus-master/app/.../AndroidManifest.xml` + new `res/xml/network_security_config.xml`
Android blocks plain HTTP by default. Added a network security config that allows
cleartext traffic only to `10.0.2.2` / `localhost` / `127.0.0.1` (for local testing),
and referenced it from the manifest with one new attribute. Everything else still
requires HTTPS.

## What was *not* changed / known limitation

`DiscussionRepository.kt` in the Android app still returns mock data. It was never
wired up to `CampusApi` in the first place (no endpoint, no mock/remote split like the
other repositories), and the database's `DiscussionThread`/`DiscussionReply` tables use
a different shape (numeric `studentID`/`moduleID` vs. the app's `author` name string and
`moduleCode`). Wiring this up needs a small design decision from your team on how to
resolve that mismatch, so it was left alone rather than guessed at.

## How to run it end-to-end

1. Start the API: `cd WeLoveCampusAPI && ./gradlew run` (listens on port 8080, connects
   to the Azure SQL database using the same credentials already in `Exposed.kt`).
2. Run the Android app on an **emulator** — `BASE_URL` is already pointed at it via
   `10.0.2.2`.
3. Open Announcements / Events in the app — they should now load from the database
   instead of the sample data.
