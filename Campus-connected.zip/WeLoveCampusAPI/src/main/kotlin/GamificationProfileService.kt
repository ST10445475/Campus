package org.welovecampus


import kotlinx.serialization.Serializable
import org.jetbrains.exposed.v1.core.dao.id.IntIdTable
import org.jetbrains.exposed.v1.jdbc.Database
import org.jetbrains.exposed.v1.jdbc.deleteWhere
import org.jetbrains.exposed.v1.jdbc.insert
import org.jetbrains.exposed.v1.jdbc.selectAll
import org.jetbrains.exposed.v1.jdbc.transactions.transaction
import org.jetbrains.exposed.v1.jdbc.update
import org.jetbrains.exposed.v1.core.eq

@Serializable
data class GamificationProfile(
    val gamificationProfileID: Int,
    val studentID: Int,
    val points: Int,
    val level: Int,
    val badgesCount: Int
)

class GamificationProfileService(
    private val database: Database
) {

    object GamificationProfiles : IntIdTable(
        "GamificationProfile",
        "GamificationProfileID"
    ) {
        val studentID = integer("StudentID")
        val points = integer("Points")
        val level = integer("Level")
        val badgesCount = integer("BadgesCount")
    }

    fun create(profile: GamificationProfile): Int = transaction(database) {
        val newRecord = GamificationProfiles.insert {
            it[studentID] = profile.studentID
            it[points] = profile.points
            it[level] = profile.level
            it[badgesCount] = profile.badgesCount
        }

        newRecord[GamificationProfiles.id].value
    }

    fun read(id: Int): GamificationProfile? {
        return transaction(database) {
            GamificationProfiles.selectAll()
                .where { GamificationProfiles.id eq id }
                .map {
                    GamificationProfile(
                        gamificationProfileID = it[GamificationProfiles.id].value,
                        studentID = it[GamificationProfiles.studentID],
                        points = it[GamificationProfiles.points],
                        level = it[GamificationProfiles.level],
                        badgesCount = it[GamificationProfiles.badgesCount]
                    )
                }
                .singleOrNull()
        }
    }

    fun update(id: Int, profile: GamificationProfile) {
        transaction(database) {
            GamificationProfiles.update({ GamificationProfiles.id eq id }) {
                it[studentID] = profile.studentID
                it[points] = profile.points
                it[level] = profile.level
                it[badgesCount] = profile.badgesCount
            }
        }
    }

    fun delete(id: Int) {
        transaction(database) {
            GamificationProfiles.deleteWhere {
                GamificationProfiles.id eq id
            }
        }
    }
}