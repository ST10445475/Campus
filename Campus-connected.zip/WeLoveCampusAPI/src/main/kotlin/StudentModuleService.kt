package org.welovecampus



import kotlinx.serialization.Serializable
import org.jetbrains.exposed.v1.core.dao.id.IntIdTable
import org.jetbrains.exposed.v1.jdbc.Database
import org.jetbrains.exposed.v1.jdbc.insert
import org.jetbrains.exposed.v1.jdbc.selectAll
import org.jetbrains.exposed.v1.jdbc.transactions.transaction
import org.jetbrains.exposed.v1.jdbc.deleteWhere
import org.jetbrains.exposed.v1.core.eq

@Serializable
data class StudentModule(
    val studentModuleID: Int,
    val studentID: Int,
    val moduleID: Int
)

class StudentModuleService(
    private val database: Database
) {

    object StudentModules : IntIdTable("StudentModules", "StudentModuleID") {
        val studentID = integer("StudentID")
        val moduleID = integer("ModuleID")
    }

    fun create(studentID: Int, moduleID: Int): Int = transaction(database) {
        val newRecord = StudentModules.insert {
            it[StudentModules.studentID] = studentID
            it[StudentModules.moduleID] = moduleID
        }

        newRecord[StudentModules.id].value
    }

    fun read(id: Int): StudentModule? {
        return transaction(database) {
            StudentModules.selectAll()
                .where { StudentModules.id eq id }
                .map {
                    StudentModule(
                        studentModuleID = it[StudentModules.id].value,
                        studentID = it[StudentModules.studentID],
                        moduleID = it[StudentModules.moduleID]
                    )
                }
                .singleOrNull()
        }
    }

    fun delete(id: Int) {
        transaction(database) {
            StudentModules.deleteWhere {
                StudentModules.id eq id
            }
        }
    }
}