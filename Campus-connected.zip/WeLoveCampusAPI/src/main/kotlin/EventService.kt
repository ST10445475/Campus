package org.welovecampus



import kotlinx.serialization.Serializable
import org.jetbrains.exposed.v1.core.dao.id.IntIdTable
import org.jetbrains.exposed.v1.jdbc.Database
import org.jetbrains.exposed.v1.jdbc.deleteWhere
import org.jetbrains.exposed.v1.jdbc.insert
import org.jetbrains.exposed.v1.jdbc.selectAll
import org.jetbrains.exposed.v1.jdbc.transactions.transaction
import org.jetbrains.exposed.v1.jdbc.update
import org.jetbrains.exposed.v1.core.eq

@Serializable
data class Event(
    val eventID: Int,
    val title: String,
    val description: String?,
    val location: String?,
    val startDateTime: String,
    val endDateTime: String?
)

class EventService(
    private val database: Database
) {

    object Events : IntIdTable("Events", "EventID") {
        val title = varchar("Title", 200)
        val description = varchar("Description", 1000).nullable()
        val location = varchar("Location", 200).nullable()
        val startDateTime = varchar("StartDateTime", 30)
        val endDateTime = varchar("EndDateTime", 30).nullable()
    }

    fun create(event: Event): Int = transaction(database) {
        val newRecord = Events.insert {
            it[title] = event.title
            it[description] = event.description
            it[location] = event.location
            it[startDateTime] = event.startDateTime
            it[endDateTime] = event.endDateTime
        }

        newRecord[Events.id].value
    }

    fun read(id: Int): Event? {
        return transaction(database) {
            Events.selectAll()
                .where { Events.id eq id }
                .map {
                    Event(
                        eventID = it[Events.id].value,
                        title = it[Events.title],
                        description = it[Events.description],
                        location = it[Events.location],
                        startDateTime = it[Events.startDateTime],
                        endDateTime = it[Events.endDateTime]
                    )
                }
                .singleOrNull()
        }
    }

    fun update(id: Int, event: Event) {
        transaction(database) {
            Events.update({ Events.id eq id }) {
                it[title] = event.title
                it[description] = event.description
                it[location] = event.location
                it[startDateTime] = event.startDateTime
                it[endDateTime] = event.endDateTime
            }
        }
    }

    fun delete(id: Int) {
        transaction(database) {
            Events.deleteWhere {
                Events.id eq id
            }
        }
    }
}