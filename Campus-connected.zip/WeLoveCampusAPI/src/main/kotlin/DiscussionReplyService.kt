package org.welovecampus



import kotlinx.serialization.Serializable
import org.jetbrains.exposed.v1.core.dao.id.IntIdTable
import org.jetbrains.exposed.v1.jdbc.Database
import org.jetbrains.exposed.v1.jdbc.deleteWhere
import org.jetbrains.exposed.v1.jdbc.insert
import org.jetbrains.exposed.v1.jdbc.selectAll
import org.jetbrains.exposed.v1.jdbc.transactions.transaction
import org.jetbrains.exposed.v1.jdbc.update
import org.jetbrains.exposed.v1.core.eq

@Serializable
data class DiscussionReply(
    val replyID: Int,
    val threadID: Int,
    val studentID: Int,
    val content: String
)

class DiscussionReplyService(
    private val database: Database
) {

    object DiscussionReplies : IntIdTable("DiscussionReplies", "ReplyID") {
        val threadID = integer("ThreadID")
        val studentID = integer("StudentID")
        val content = text("Content")
    }

    fun create(reply: DiscussionReply): Int = transaction(database) {
        val newRecord = DiscussionReplies.insert {
            it[threadID] = reply.threadID
            it[studentID] = reply.studentID
            it[content] = reply.content
        }

        newRecord[DiscussionReplies.id].value
    }

    fun read(id: Int): DiscussionReply? {
        return transaction(database) {
            DiscussionReplies.selectAll()
                .where { DiscussionReplies.id eq id }
                .map {
                    DiscussionReply(
                        replyID = it[DiscussionReplies.id].value,
                        threadID = it[DiscussionReplies.threadID],
                        studentID = it[DiscussionReplies.studentID],
                        content = it[DiscussionReplies.content]
                    )
                }
                .singleOrNull()
        }
    }

    fun update(id: Int, reply: DiscussionReply) {
        transaction(database) {
            DiscussionReplies.update({ DiscussionReplies.id eq id }) {
                it[threadID] = reply.threadID
                it[studentID] = reply.studentID
                it[content] = reply.content
            }
        }
    }

    fun delete(id: Int) {
        transaction(database) {
            DiscussionReplies.deleteWhere {
                DiscussionReplies.id eq id
            }
        }
    }
}