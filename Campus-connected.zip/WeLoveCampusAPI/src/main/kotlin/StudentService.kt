package org.welovecampus

import kotlinx.serialization.Serializable
import org.jetbrains.exposed.v1.core.dao.id.IntIdTable
import org.jetbrains.exposed.v1.jdbc.Database
import org.jetbrains.exposed.v1.jdbc.deleteWhere
import org.jetbrains.exposed.v1.jdbc.insert
import org.jetbrains.exposed.v1.jdbc.selectAll
import org.jetbrains.exposed.v1.jdbc.transactions.transaction
import org.jetbrains.exposed.v1.jdbc.update
import org.jetbrains.exposed.v1.core.eq

@Serializable
data class Student(
    val studentID: Int,
    val firstName: String,
    val lastName: String,
    val email: String,
    val passwordHash: String?,
    val googleID: String?,
    val phoneNumber: String?,
    val preferredLanguage: String
)

class StudentService(
    private val database: Database
) {

    object Students : IntIdTable("Students", "StudentID") {
        val firstName = varchar("FirstName", 50)
        val lastName = varchar("LastName", 50)
        val email = varchar("Email", 100)
        val passwordHash = varchar("PasswordHash", 255).nullable()
        val googleID = varchar("GoogleID", 255).nullable()
        val phoneNumber = varchar("PhoneNumber", 20).nullable()
        val preferredLanguage = varchar("PreferredLanguage", 20)
    }

    fun create(student: Student): Int = transaction(database) {
        val newRecord = Students.insert {
            it[firstName] = student.firstName
            it[lastName] = student.lastName
            it[email] = student.email
            it[passwordHash] = student.passwordHash
            it[googleID] = student.googleID
            it[phoneNumber] = student.phoneNumber
            it[preferredLanguage] = student.preferredLanguage
        }

        newRecord[Students.id].value
    }

    fun read(id: Int): Student? {
        return transaction(database) {
            Students.selectAll()
                .where { Students.id eq id }
                .map {
                    Student(
                        studentID = it[Students.id].value,
                        firstName = it[Students.firstName],
                        lastName = it[Students.lastName],
                        email = it[Students.email],
                        passwordHash = it[Students.passwordHash],
                        googleID = it[Students.googleID],
                        phoneNumber = it[Students.phoneNumber],
                        preferredLanguage = it[Students.preferredLanguage]
                    )
                }
                .singleOrNull()
        }
    }

    fun update(id: Int, student: Student) {
        transaction(database) {
            Students.update({ Students.id eq id }) {
                it[firstName] = student.firstName
                it[lastName] = student.lastName
                it[email] = student.email
                it[passwordHash] = student.passwordHash
                it[googleID] = student.googleID
                it[phoneNumber] = student.phoneNumber
                it[preferredLanguage] = student.preferredLanguage
            }
        }
    }

    fun delete(id: Int) {
        transaction(database) {
            Students.deleteWhere {
                Students.id eq id
            }
        }
    }
}