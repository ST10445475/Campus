package org.welovecampus


import kotlinx.serialization.Serializable
import org.jetbrains.exposed.v1.core.dao.id.IntIdTable
import org.jetbrains.exposed.v1.jdbc.Database
import org.jetbrains.exposed.v1.jdbc.deleteWhere
import org.jetbrains.exposed.v1.jdbc.insert
import org.jetbrains.exposed.v1.jdbc.selectAll
import org.jetbrains.exposed.v1.jdbc.transactions.transaction
import org.jetbrains.exposed.v1.jdbc.update
import org.jetbrains.exposed.v1.core.eq

@Serializable
data class Assignment(
    val assignmentID: Int,
    val moduleID: Int,
    val title: String,
    val description: String?,
    val dueDate: String,
    val status: String
)

class AssignmentService(
    private val database: Database
) {

    object Assignments : IntIdTable("Assignments", "AssignmentID") {
        val moduleID = integer("ModuleID")
        val title = varchar("Title", 150)
        val description = varchar("Description", 1000).nullable()
        val dueDate = varchar("DueDate", 30)
        val status = varchar("Status", 30)
    }

    fun create(assignment: Assignment): Int = transaction(database) {
        val newRecord = Assignments.insert {
            it[moduleID] = assignment.moduleID
            it[title] = assignment.title
            it[description] = assignment.description
            it[dueDate] = assignment.dueDate
            it[status] = assignment.status
        }

        newRecord[Assignments.id].value
    }

    fun read(id: Int): Assignment? {
        return transaction(database) {
            Assignments.selectAll()
                .where { Assignments.id eq id }
                .map {
                    Assignment(
                        assignmentID = it[Assignments.id].value,
                        moduleID = it[Assignments.moduleID],
                        title = it[Assignments.title],
                        description = it[Assignments.description],
                        dueDate = it[Assignments.dueDate],
                        status = it[Assignments.status]
                    )
                }
                .singleOrNull()
        }
    }

    fun update(id: Int, assignment: Assignment) {
        transaction(database) {
            Assignments.update({ Assignments.id eq id }) {
                it[moduleID] = assignment.moduleID
                it[title] = assignment.title
                it[description] = assignment.description
                it[dueDate] = assignment.dueDate
                it[status] = assignment.status
            }
        }
    }

    fun delete(id: Int) {
        transaction(database) {
            Assignments.deleteWhere {
                Assignments.id eq id
            }
        }
    }
}