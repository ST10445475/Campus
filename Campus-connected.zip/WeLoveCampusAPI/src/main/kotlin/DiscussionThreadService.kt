package org.welovecampus


import kotlinx.serialization.Serializable
import org.jetbrains.exposed.v1.core.dao.id.IntIdTable
import org.jetbrains.exposed.v1.jdbc.Database
import org.jetbrains.exposed.v1.jdbc.deleteWhere
import org.jetbrains.exposed.v1.jdbc.insert
import org.jetbrains.exposed.v1.jdbc.selectAll
import org.jetbrains.exposed.v1.jdbc.transactions.transaction
import org.jetbrains.exposed.v1.jdbc.update
import org.jetbrains.exposed.v1.core.eq

@Serializable
data class DiscussionThread(
    val threadID: Int,
    val studentID: Int,
    val moduleID: Int,
    val title: String,
    val content: String
)

class DiscussionThreadService(
    private val database: Database
) {

    object DiscussionThreads : IntIdTable("DiscussionThreads", "ThreadID") {
        val studentID = integer("StudentID")
        val moduleID = integer("ModuleID")
        val title = varchar("Title", 200)
        val content = text("Content")
    }

    fun create(thread: DiscussionThread): Int = transaction(database) {
        val newRecord = DiscussionThreads.insert {
            it[studentID] = thread.studentID
            it[moduleID] = thread.moduleID
            it[title] = thread.title
            it[content] = thread.content
        }

        newRecord[DiscussionThreads.id].value
    }

    fun read(id: Int): DiscussionThread? {
        return transaction(database) {
            DiscussionThreads.selectAll()
                .where { DiscussionThreads.id eq id }
                .map {
                    DiscussionThread(
                        threadID = it[DiscussionThreads.id].value,
                        studentID = it[DiscussionThreads.studentID],
                        moduleID = it[DiscussionThreads.moduleID],
                        title = it[DiscussionThreads.title],
                        content = it[DiscussionThreads.content]
                    )
                }
                .singleOrNull()
        }
    }

    fun update(id: Int, thread: DiscussionThread) {
        transaction(database) {
            DiscussionThreads.update({ DiscussionThreads.id eq id }) {
                it[studentID] = thread.studentID
                it[moduleID] = thread.moduleID
                it[title] = thread.title
                it[content] = thread.content
            }
        }
    }

    fun delete(id: Int) {
        transaction(database) {
            DiscussionThreads.deleteWhere {
                DiscussionThreads.id eq id
            }
        }
    }
}