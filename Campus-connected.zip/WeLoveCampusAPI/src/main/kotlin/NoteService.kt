package org.welovecampus



import kotlinx.serialization.Serializable
import org.jetbrains.exposed.v1.core.dao.id.IntIdTable
import org.jetbrains.exposed.v1.jdbc.Database
import org.jetbrains.exposed.v1.jdbc.deleteWhere
import org.jetbrains.exposed.v1.jdbc.insert
import org.jetbrains.exposed.v1.jdbc.selectAll
import org.jetbrains.exposed.v1.jdbc.transactions.transaction
import org.jetbrains.exposed.v1.jdbc.update
import org.jetbrains.exposed.v1.core.eq

@Serializable
data class Note(
    val noteID: Int,
    val studentID: Int,
    val moduleID: Int?,
    val title: String,
    val content: String
)

class NoteService(
    private val database: Database
) {

    object Notes : IntIdTable("Notes", "NoteID") {
        val studentID = integer("StudentID")
        val moduleID = integer("ModuleID").nullable()
        val title = varchar("Title", 150)
        val content = text("Content")
    }

    fun create(note: Note): Int = transaction(database) {
        val newRecord = Notes.insert {
            it[studentID] = note.studentID
            it[moduleID] = note.moduleID
            it[title] = note.title
            it[content] = note.content
        }

        newRecord[Notes.id].value
    }

    fun read(id: Int): Note? {
        return transaction(database) {
            Notes.selectAll()
                .where { Notes.id eq id }
                .map {
                    Note(
                        noteID = it[Notes.id].value,
                        studentID = it[Notes.studentID],
                        moduleID = it[Notes.moduleID],
                        title = it[Notes.title],
                        content = it[Notes.content]
                    )
                }
                .singleOrNull()
        }
    }

    fun update(id: Int, note: Note) {
        transaction(database) {
            Notes.update({ Notes.id eq id }) {
                it[studentID] = note.studentID
                it[moduleID] = note.moduleID
                it[title] = note.title
                it[content] = note.content
            }
        }
    }

    fun delete(id: Int) {
        transaction(database) {
            Notes.deleteWhere {
                Notes.id eq id
            }
        }
    }
}