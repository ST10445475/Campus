package org.welovecampus



import kotlinx.serialization.Serializable
import org.jetbrains.exposed.v1.core.dao.id.IntIdTable
import org.jetbrains.exposed.v1.jdbc.Database
import org.jetbrains.exposed.v1.jdbc.deleteWhere
import org.jetbrains.exposed.v1.jdbc.insert
import org.jetbrains.exposed.v1.jdbc.selectAll
import org.jetbrains.exposed.v1.jdbc.transactions.transaction
import org.jetbrains.exposed.v1.jdbc.update
import org.jetbrains.exposed.v1.core.eq

@Serializable
data class NotificationPreference(
    val notificationPreferenceID: Int,
    val studentID: Int,
    val assignmentNotifications: Boolean,
    val announcementNotifications: Boolean,
    val eventNotifications: Boolean,
    val discussionNotifications: Boolean
)

class NotificationPreferencesService(
    private val database: Database
) {

    object NotificationPreferences : IntIdTable(
        "NotificationPreferences",
        "NotificationPreferenceID"
    ) {
        val studentID = integer("StudentID")
        val assignmentNotifications = bool("AssignmentNotifications")
        val announcementNotifications = bool("AnnouncementNotifications")
        val eventNotifications = bool("EventNotifications")
        val discussionNotifications = bool("DiscussionNotifications")
    }

    fun create(preference: NotificationPreference): Int = transaction(database) {
        val newRecord = NotificationPreferences.insert {
            it[studentID] = preference.studentID
            it[assignmentNotifications] = preference.assignmentNotifications
            it[announcementNotifications] = preference.announcementNotifications
            it[eventNotifications] = preference.eventNotifications
            it[discussionNotifications] = preference.discussionNotifications
        }

        newRecord[NotificationPreferences.id].value
    }

    fun read(id: Int): NotificationPreference? {
        return transaction(database) {
            NotificationPreferences.selectAll()
                .where { NotificationPreferences.id eq id }
                .map {
                    NotificationPreference(
                        notificationPreferenceID = it[NotificationPreferences.id].value,
                        studentID = it[NotificationPreferences.studentID],
                        assignmentNotifications = it[NotificationPreferences.assignmentNotifications],
                        announcementNotifications = it[NotificationPreferences.announcementNotifications],
                        eventNotifications = it[NotificationPreferences.eventNotifications],
                        discussionNotifications = it[NotificationPreferences.discussionNotifications]
                    )
                }
                .singleOrNull()
        }
    }

    fun update(id: Int, preference: NotificationPreference) {
        transaction(database) {
            NotificationPreferences.update({ NotificationPreferences.id eq id }) {
                it[studentID] = preference.studentID
                it[assignmentNotifications] = preference.assignmentNotifications
                it[announcementNotifications] = preference.announcementNotifications
                it[eventNotifications] = preference.eventNotifications
                it[discussionNotifications] = preference.discussionNotifications
            }
        }
    }

    fun delete(id: Int) {
        transaction(database) {
            NotificationPreferences.deleteWhere {
                NotificationPreferences.id eq id
            }
        }
    }
}