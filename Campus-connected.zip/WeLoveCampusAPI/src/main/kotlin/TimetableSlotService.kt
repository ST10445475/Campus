package org.welovecampus



import kotlinx.serialization.Serializable
import org.jetbrains.exposed.v1.core.dao.id.IntIdTable
import org.jetbrains.exposed.v1.jdbc.Database
import org.jetbrains.exposed.v1.jdbc.deleteWhere
import org.jetbrains.exposed.v1.jdbc.insert
import org.jetbrains.exposed.v1.jdbc.selectAll
import org.jetbrains.exposed.v1.jdbc.transactions.transaction
import org.jetbrains.exposed.v1.jdbc.update
import org.jetbrains.exposed.v1.core.eq

@Serializable
data class TimetableSlot(
    val timetableSlotID: Int,
    val studentID: Int,
    val moduleID: Int,
    val dayOfWeek: String,
    val startTime: String,
    val endTime: String,
    val room: String?
)

class TimetableSlotService(
    private val database: Database
) {

    object TimetableSlots : IntIdTable("TimetableSlots", "TimetableSlotID") {
        val studentID = integer("StudentID")
        val moduleID = integer("ModuleID")
        val dayOfWeek = varchar("DayOfWeek", 20)
        val startTime = varchar("StartTime", 8)
        val endTime = varchar("EndTime", 8)
        val room = varchar("Room", 50).nullable()
    }

    fun create(slot: TimetableSlot): Int = transaction(database) {
        val newRecord = TimetableSlots.insert {
            it[studentID] = slot.studentID
            it[moduleID] = slot.moduleID
            it[dayOfWeek] = slot.dayOfWeek
            it[startTime] = slot.startTime
            it[endTime] = slot.endTime
            it[room] = slot.room
        }

        newRecord[TimetableSlots.id].value
    }

    fun read(id: Int): TimetableSlot? {
        return transaction(database) {
            TimetableSlots.selectAll()
                .where { TimetableSlots.id eq id }
                .map {
                    TimetableSlot(
                        timetableSlotID = it[TimetableSlots.id].value,
                        studentID = it[TimetableSlots.studentID],
                        moduleID = it[TimetableSlots.moduleID],
                        dayOfWeek = it[TimetableSlots.dayOfWeek],
                        startTime = it[TimetableSlots.startTime],
                        endTime = it[TimetableSlots.endTime],
                        room = it[TimetableSlots.room]
                    )
                }
                .singleOrNull()
        }
    }

    fun update(id: Int, slot: TimetableSlot) {
        transaction(database) {
            TimetableSlots.update({ TimetableSlots.id eq id }) {
                it[studentID] = slot.studentID
                it[moduleID] = slot.moduleID
                it[dayOfWeek] = slot.dayOfWeek
                it[startTime] = slot.startTime
                it[endTime] = slot.endTime
                it[room] = slot.room
            }
        }
    }

    fun delete(id: Int) {
        transaction(database) {
            TimetableSlots.deleteWhere {
                TimetableSlots.id eq id
            }
        }
    }
}