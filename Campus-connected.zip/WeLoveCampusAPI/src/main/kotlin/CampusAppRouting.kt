package org.welovecampus

import io.ktor.http.HttpStatusCode
import io.ktor.server.application.*
import io.ktor.server.request.receive
import io.ktor.server.response.respond
import io.ktor.server.routing.get
import io.ktor.server.routing.post
import io.ktor.server.routing.routing
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import org.jetbrains.exposed.v1.core.SortOrder
import org.jetbrains.exposed.v1.core.dao.id.IntIdTable
import org.jetbrains.exposed.v1.core.eq
import org.jetbrains.exposed.v1.jdbc.Database
import org.jetbrains.exposed.v1.jdbc.SchemaUtils
import org.jetbrains.exposed.v1.jdbc.insert
import org.jetbrains.exposed.v1.jdbc.selectAll
import org.jetbrains.exposed.v1.jdbc.transactions.transaction
import org.jetbrains.exposed.v1.jdbc.update

/**
 * =====================================================================================
 *  CAMPUS <-> WELOVECAMPUS API BRIDGE
 * =====================================================================================
 *
 * Person 5's Android app (see CampusApi.kt) was already written to call:
 *
 *      GET  /api/announcements?category=            -> List<Announcement>
 *      GET  /api/events                              -> List<CampusEvent>
 *      POST /api/notifications/register  (body)      -> RegistrationResponse
 *
 * Person 1's API (Exposed.kt / Routing.kt) exposes CRUD-by-id routes with no "/api"
 * prefix and no "list everything" endpoints, so the app had nothing to actually call.
 *
 * This file ADDS the missing endpoints without touching any existing file:
 *   - It opens its own connection to the SAME Azure SQL database using the SAME
 *     connection string already used in Exposed.kt.
 *   - It queries the SAME "Announcements" / "Events" tables already declared in
 *     AnnouncementService.kt / EventService.kt (they are public nested objects, so
 *     they can be reused here as-is).
 *   - It adds one new small table, DeviceRegistrations, to persist push-notification
 *     tokens, since the existing schema had no place to store them.
 *
 * NOTE ON FIELD MAPPING (please read):
 * The Android app's Announcement model (sender/message/category/timestamp) and the
 * database's Announcement table (title/content/moduleID/expiryDate) don't describe
 * the same fields 1:1 - the database has no "sender", "category" or "posted at"
 * timestamp. Rather than invent columns, this bridge derives sensible values:
 *   - sender      -> "Module <id>" if the announcement has a moduleID, else "Campus"
 *   - message     -> "<title>: <content>" (keeps all the original text)
 *   - category    -> "Academic" if it has a moduleID, else "Administrative"
 *                    (there's no way to detect "Emergency" from the current schema)
 *   - timestamp   -> parsed from expiryDate if present/parseable, else "now"
 * If you'd rather the database carry these fields directly, add Sender/Category/
 * PostedAt columns to the Announcements table and swap the mapping below.
 * =====================================================================================
 */

// ---------- JSON shapes that exactly match Campus's CampusApi.kt / data/model classes ----------

@Serializable
data class AppAnnouncement(
    val announcementId: String,
    val sender: String,
    val message: String,
    val category: String, // "Academic" | "Administrative" | "Emergency"
    val timestamp: Long
)

@Serializable
data class AppEvent(
    val eventId: String,
    val title: String,
    val startTime: Long,
    val location: String
)

@Serializable
data class AppDeviceRegistration(
    val fcmToken: String,
    val preferences: Map<String, Boolean>
)

@Serializable
data class AppRegistrationResponse(
    val success: Boolean = true,
    val message: String? = null
)

/** New table (created automatically on startup) to store each device's FCM token
 *  and notification preferences, sent by POST /api/notifications/register. */
object DeviceRegistrations : IntIdTable("DeviceRegistrations", "DeviceRegistrationID") {
    val fcmToken = varchar("FcmToken", 300).uniqueIndex()
    val preferencesJson = text("PreferencesJson")
}

private fun parseTimestampOrNow(value: String?): Long {
    if (value.isNullOrBlank()) return System.currentTimeMillis()
    return try {
        java.time.Instant.parse(value).toEpochMilli()
    } catch (e: Exception) {
        try {
            java.time.LocalDateTime.parse(value)
                .atZone(java.time.ZoneId.systemDefault())
                .toInstant()
                .toEpochMilli()
        } catch (e2: Exception) {
            System.currentTimeMillis()
        }
    }
}

fun Application.configureCampusAppApi() {

    // Same Azure SQL Database that configureExposed() in Exposed.kt connects to.
    val database = Database.connect(
        url = "jdbc:sqlserver://welovecampus-sql-server.database.windows.net:1433;databaseName=WeLoveCampusDB;encrypt=true;trustServerCertificate=false;hostNameInCertificate=*.database.windows.net;loginTimeout=30",
        user = "campusadmin@welovecampus-sql-server",
        password = "welovecampus@26"
    )

    transaction(database) {
        SchemaUtils.create(DeviceRegistrations)
    }

    routing {

        // GET /api/announcements?category=Academic|Administrative|Emergency
        get("/api/announcements") {
            val categoryFilter = call.request.queryParameters["category"]

            val announcements = transaction(database) {
                AnnouncementService.Announcements
                    .selectAll()
                    .orderBy(AnnouncementService.Announcements.id, SortOrder.DESC)
                    .map { row ->
                        val moduleId = row[AnnouncementService.Announcements.moduleID]
                        AppAnnouncement(
                            announcementId = row[AnnouncementService.Announcements.id].value.toString(),
                            sender = if (moduleId != null) "Module $moduleId" else "Campus",
                            message = "${row[AnnouncementService.Announcements.title]}: " +
                                row[AnnouncementService.Announcements.content],
                            category = if (moduleId != null) "Academic" else "Administrative",
                            timestamp = parseTimestampOrNow(row[AnnouncementService.Announcements.expiryDate])
                        )
                    }
            }

            val result = if (categoryFilter.isNullOrBlank()) {
                announcements
            } else {
                announcements.filter { it.category.equals(categoryFilter, ignoreCase = true) }
            }

            call.respond(HttpStatusCode.OK, result)
        }

        // GET /api/events
        get("/api/events") {
            val events = transaction(database) {
                EventService.Events
                    .selectAll()
                    .orderBy(EventService.Events.id, SortOrder.DESC)
                    .map { row ->
                        AppEvent(
                            eventId = row[EventService.Events.id].value.toString(),
                            title = row[EventService.Events.title],
                            startTime = parseTimestampOrNow(row[EventService.Events.startDateTime]),
                            location = row[EventService.Events.location] ?: ""
                        )
                    }
            }
            call.respond(HttpStatusCode.OK, events)
        }

        // POST /api/notifications/register
        post("/api/notifications/register") {
            val body = call.receive<AppDeviceRegistration>()
            val prefsJson = Json.encodeToString(body.preferences)

            transaction(database) {
                val existing = DeviceRegistrations
                    .selectAll()
                    .where { DeviceRegistrations.fcmToken eq body.fcmToken }
                    .singleOrNull()

                if (existing != null) {
                    DeviceRegistrations.update({ DeviceRegistrations.fcmToken eq body.fcmToken }) {
                        it[preferencesJson] = prefsJson
                    }
                } else {
                    DeviceRegistrations.insert {
                        it[fcmToken] = body.fcmToken
                        it[preferencesJson] = prefsJson
                    }
                }
            }

            call.respond(HttpStatusCode.OK, AppRegistrationResponse(success = true, message = "registered"))
        }
    }
}
