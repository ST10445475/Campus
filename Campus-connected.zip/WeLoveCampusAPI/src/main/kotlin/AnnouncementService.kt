package org.welovecampus



import kotlinx.serialization.Serializable
import org.jetbrains.exposed.v1.core.dao.id.IntIdTable
import org.jetbrains.exposed.v1.jdbc.Database
import org.jetbrains.exposed.v1.jdbc.deleteWhere
import org.jetbrains.exposed.v1.jdbc.insert
import org.jetbrains.exposed.v1.jdbc.selectAll
import org.jetbrains.exposed.v1.jdbc.transactions.transaction
import org.jetbrains.exposed.v1.jdbc.update
import org.jetbrains.exposed.v1.core.eq

@Serializable
data class Announcement(
    val announcementID: Int,
    val title: String,
    val content: String,
    val moduleID: Int?,
    val expiryDate: String?
)

class AnnouncementService(
    private val database: Database
) {

    object Announcements : IntIdTable("Announcements", "AnnouncementID") {
        val title = varchar("Title", 200)
        val content = text("Content")
        val moduleID = integer("ModuleID").nullable()
        val expiryDate = varchar("ExpiryDate", 30).nullable()
    }

    fun create(announcement: Announcement): Int = transaction(database) {
        val newRecord = Announcements.insert {
            it[title] = announcement.title
            it[content] = announcement.content
            it[moduleID] = announcement.moduleID
            it[expiryDate] = announcement.expiryDate
        }

        newRecord[Announcements.id].value
    }

    fun read(id: Int): Announcement? {
        return transaction(database) {
            Announcements.selectAll()
                .where { Announcements.id eq id }
                .map {
                    Announcement(
                        announcementID = it[Announcements.id].value,
                        title = it[Announcements.title],
                        content = it[Announcements.content],
                        moduleID = it[Announcements.moduleID],
                        expiryDate = it[Announcements.expiryDate]
                    )
                }
                .singleOrNull()
        }
    }

    fun update(id: Int, announcement: Announcement) {
        transaction(database) {
            Announcements.update({ Announcements.id eq id }) {
                it[title] = announcement.title
                it[content] = announcement.content
                it[moduleID] = announcement.moduleID
                it[expiryDate] = announcement.expiryDate
            }
        }
    }

    fun delete(id: Int) {
        transaction(database) {
            Announcements.deleteWhere {
                Announcements.id eq id
            }
        }
    }
}