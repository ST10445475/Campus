package org.welovecampus

import kotlinx.serialization.Serializable
import org.jetbrains.exposed.v1.core.dao.id.IntIdTable
import org.jetbrains.exposed.v1.jdbc.Database
import org.jetbrains.exposed.v1.jdbc.deleteWhere
import org.jetbrains.exposed.v1.jdbc.insert
import org.jetbrains.exposed.v1.jdbc.selectAll
import org.jetbrains.exposed.v1.jdbc.transactions.transaction
import org.jetbrains.exposed.v1.jdbc.update
import org.jetbrains.exposed.v1.core.eq

@Serializable
data class Module(
    val moduleID: Int,
    val moduleCode: String,
    val moduleName: String,
    val description: String?
)

class ModuleService(
    private val database: Database
) {

    object Modules : IntIdTable("Modules", "ModuleID") {
        val moduleCode = varchar("ModuleCode", 20)
        val moduleName = varchar("ModuleName", 100)
        val description = varchar("Description", 500).nullable()
    }

    fun create(module: Module): Int = transaction(database) {
        val newRecord = Modules.insert {
            it[moduleCode] = module.moduleCode
            it[moduleName] = module.moduleName
            it[description] = module.description
        }

        newRecord[Modules.id].value
    }

    fun read(id: Int): Module? {
        return transaction(database) {
            Modules.selectAll()
                .where { Modules.id eq id }
                .map {
                    Module(
                        moduleID = it[Modules.id].value,
                        moduleCode = it[Modules.moduleCode],
                        moduleName = it[Modules.moduleName],
                        description = it[Modules.description]
                    )
                }
                .singleOrNull()
        }
    }

    fun update(id: Int, module: Module) {
        transaction(database) {
            Modules.update({ Modules.id eq id }) {
                it[moduleCode] = module.moduleCode
                it[moduleName] = module.moduleName
                it[description] = module.description
            }
        }
    }

    fun delete(id: Int) {
        transaction(database) {
            Modules.deleteWhere {
                Modules.id eq id
            }
        }
    }
}