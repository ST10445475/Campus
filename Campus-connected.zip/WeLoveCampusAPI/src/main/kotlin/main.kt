package org.welovecampus

fun main(args: Array<String>) {
    io.ktor.server.netty.EngineMain.main(args)
}
