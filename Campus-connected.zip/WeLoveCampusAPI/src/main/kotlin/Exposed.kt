package org.welovecampus

import io.ktor.http.HttpStatusCode
import io.ktor.server.application.*
import io.ktor.server.request.receive
import io.ktor.server.response.respond
import io.ktor.server.routing.delete
import io.ktor.server.routing.get
import io.ktor.server.routing.post
import io.ktor.server.routing.put
import io.ktor.server.routing.routing
import org.jetbrains.exposed.v1.jdbc.Database

@kotlinx.serialization.Serializable
data class EnrollStudentRequest(
    val studentID: Int,
    val moduleID: Int
)

suspend fun Application.configureExposed() {

    val database = Database.connect(
        url = "jdbc:sqlserver://welovecampus-sql-server.database.windows.net:1433;databaseName=WeLoveCampusDB;encrypt=true;trustServerCertificate=false;hostNameInCertificate=*.database.windows.net;loginTimeout=30",
        user = "campusadmin@welovecampus-sql-server",
        password = "welovecampus@26"
    )
    val studentService = StudentService(database)
    val moduleService = ModuleService(database)
    val studentModuleService = StudentModuleService(database)
    val timetableSlotService = TimetableSlotService(database)
    val assignmentService = AssignmentService(database)
    val noteService = NoteService(database)
    val discussionThreadService = DiscussionThreadService(database)
    val discussionReplyService = DiscussionReplyService(database)
    val announcementService = AnnouncementService(database)
    val eventService = EventService(database)
    val gamificationProfileService = GamificationProfileService(database)
    val notificationPreferencesService = NotificationPreferencesService(database)
    routing {

        // =========================
        // STUDENTS
        // =========================
// STUDENT MODULES

        post("/student-modules") {
            val request = call.receive<EnrollStudentRequest>()

            val id = studentModuleService.create(
                request.studentID,
                request.moduleID
            )

            call.respond(HttpStatusCode.Created, id)
        }

        get("/student-modules/{id}") {
            val id = call.parameters["id"]?.toInt()
                ?: throw IllegalArgumentException("Invalid ID")

            val studentModule = studentModuleService.read(id)

            if (studentModule != null) {
                call.respond(HttpStatusCode.OK, studentModule)
            } else {
                call.respond(HttpStatusCode.NotFound)
            }
        }

        delete("/student-modules/{id}") {
            val id = call.parameters["id"]?.toInt()
                ?: throw IllegalArgumentException("Invalid ID")

            studentModuleService.delete(id)

            call.respond(HttpStatusCode.NoContent)
        }
        post("/students") {
            val student = call.receive<Student>()
            val id = studentService.create(student)
            call.respond(HttpStatusCode.Created, id)
        }

        get("/students/{id}") {
            val id = call.parameters["id"]?.toInt()
                ?: throw IllegalArgumentException("Invalid ID")

            val student = studentService.read(id)

            if (student != null) {
                call.respond(HttpStatusCode.OK, student)
            } else {
                call.respond(HttpStatusCode.NotFound)
            }
        }

        put("/students/{id}") {
            val id = call.parameters["id"]?.toInt()
                ?: throw IllegalArgumentException("Invalid ID")

            val student = call.receive<Student>()
            studentService.update(id, student)

            call.respond(HttpStatusCode.NoContent)
        }

        delete("/students/{id}") {
            val id = call.parameters["id"]?.toInt()
                ?: throw IllegalArgumentException("Invalid ID")

            studentService.delete(id)

            call.respond(HttpStatusCode.NoContent)
        }


        // =========================
        // MODULES
        // =========================

        post("/modules") {
            val module = call.receive<Module>()
            val id = moduleService.create(module)

            call.respond(HttpStatusCode.Created, id)
        }

        get("/modules/{id}") {
            val id = call.parameters["id"]?.toInt()
                ?: throw IllegalArgumentException("Invalid ID")

            val module = moduleService.read(id)

            if (module != null) {
                call.respond(HttpStatusCode.OK, module)
            } else {
                call.respond(HttpStatusCode.NotFound)
            }
        }

        put("/modules/{id}") {
            val id = call.parameters["id"]?.toInt()
                ?: throw IllegalArgumentException("Invalid ID")

            val module = call.receive<Module>()
            moduleService.update(id, module)

            call.respond(HttpStatusCode.NoContent)
        }

        delete("/modules/{id}") {
            val id = call.parameters["id"]?.toInt()
                ?: throw IllegalArgumentException("Invalid ID")

            moduleService.delete(id)

            call.respond(HttpStatusCode.NoContent)
        }

        // TIMETABLE SLOTS

        post("/timetable-slots") {
            val slot = call.receive<TimetableSlot>()
            val id = timetableSlotService.create(slot)

            call.respond(HttpStatusCode.Created, id)
        }

        get("/timetable-slots/{id}") {
            val id = call.parameters["id"]?.toInt()
                ?: throw IllegalArgumentException("Invalid ID")

            val slot = timetableSlotService.read(id)

            if (slot != null) {
                call.respond(HttpStatusCode.OK, slot)
            } else {
                call.respond(HttpStatusCode.NotFound)
            }
        }

        put("/timetable-slots/{id}") {
            val id = call.parameters["id"]?.toInt()
                ?: throw IllegalArgumentException("Invalid ID")

            val slot = call.receive<TimetableSlot>()
            timetableSlotService.update(id, slot)

            call.respond(HttpStatusCode.NoContent)
        }

        delete("/timetable-slots/{id}") {
            val id = call.parameters["id"]?.toInt()
                ?: throw IllegalArgumentException("Invalid ID")

            timetableSlotService.delete(id)

            call.respond(HttpStatusCode.NoContent)
        }

        // ASSIGNMENTS

        post("/assignments") {
            val assignment = call.receive<Assignment>()
            val id = assignmentService.create(assignment)

            call.respond(HttpStatusCode.Created, id)
        }

        get("/assignments/{id}") {
            val id = call.parameters["id"]?.toInt()
                ?: throw IllegalArgumentException("Invalid ID")

            val assignment = assignmentService.read(id)

            if (assignment != null) {
                call.respond(HttpStatusCode.OK, assignment)
            } else {
                call.respond(HttpStatusCode.NotFound)
            }
        }

        put("/assignments/{id}") {
            val id = call.parameters["id"]?.toInt()
                ?: throw IllegalArgumentException("Invalid ID")

            val assignment = call.receive<Assignment>()
            assignmentService.update(id, assignment)

            call.respond(HttpStatusCode.NoContent)
        }

        delete("/assignments/{id}") {
            val id = call.parameters["id"]?.toInt()
                ?: throw IllegalArgumentException("Invalid ID")

            assignmentService.delete(id)

            call.respond(HttpStatusCode.NoContent)
        }

        // NOTES

        post("/notes") {
            val note = call.receive<Note>()
            val id = noteService.create(note)

            call.respond(HttpStatusCode.Created, id)
        }

        get("/notes/{id}") {
            val id = call.parameters["id"]?.toInt()
                ?: throw IllegalArgumentException("Invalid ID")

            val note = noteService.read(id)

            if (note != null) {
                call.respond(HttpStatusCode.OK, note)
            } else {
                call.respond(HttpStatusCode.NotFound)
            }
        }

        put("/notes/{id}") {
            val id = call.parameters["id"]?.toInt()
                ?: throw IllegalArgumentException("Invalid ID")

            val note = call.receive<Note>()
            noteService.update(id, note)

            call.respond(HttpStatusCode.NoContent)
        }

        delete("/notes/{id}") {
            val id = call.parameters["id"]?.toInt()
                ?: throw IllegalArgumentException("Invalid ID")

            noteService.delete(id)

            call.respond(HttpStatusCode.NoContent)
        }

        // DISCUSSION THREADS

        post("/discussion-threads") {
            val thread = call.receive<DiscussionThread>()
            val id = discussionThreadService.create(thread)

            call.respond(HttpStatusCode.Created, id)
        }

        get("/discussion-threads/{id}") {
            val id = call.parameters["id"]?.toInt()
                ?: throw IllegalArgumentException("Invalid ID")

            val thread = discussionThreadService.read(id)

            if (thread != null) {
                call.respond(HttpStatusCode.OK, thread)
            } else {
                call.respond(HttpStatusCode.NotFound)
            }
        }

        put("/discussion-threads/{id}") {
            val id = call.parameters["id"]?.toInt()
                ?: throw IllegalArgumentException("Invalid ID")

            val thread = call.receive<DiscussionThread>()
            discussionThreadService.update(id, thread)

            call.respond(HttpStatusCode.NoContent)
        }

        delete("/discussion-threads/{id}") {
            val id = call.parameters["id"]?.toInt()
                ?: throw IllegalArgumentException("Invalid ID")

            discussionThreadService.delete(id)

            call.respond(HttpStatusCode.NoContent)
        }

        // DISCUSSION REPLIES

        post("/discussion-replies") {
            val reply = call.receive<DiscussionReply>()
            val id = discussionReplyService.create(reply)

            call.respond(HttpStatusCode.Created, id)
        }

        get("/discussion-replies/{id}") {
            val id = call.parameters["id"]?.toInt()
                ?: throw IllegalArgumentException("Invalid ID")

            val reply = discussionReplyService.read(id)

            if (reply != null) {
                call.respond(HttpStatusCode.OK, reply)
            } else {
                call.respond(HttpStatusCode.NotFound)
            }
        }

        put("/discussion-replies/{id}") {
            val id = call.parameters["id"]?.toInt()
                ?: throw IllegalArgumentException("Invalid ID")

            val reply = call.receive<DiscussionReply>()
            discussionReplyService.update(id, reply)

            call.respond(HttpStatusCode.NoContent)
        }

        delete("/discussion-replies/{id}") {
            val id = call.parameters["id"]?.toInt()
                ?: throw IllegalArgumentException("Invalid ID")

            discussionReplyService.delete(id)

            call.respond(HttpStatusCode.NoContent)
        }

        // ANNOUNCEMENTS

        post("/announcements") {
            val announcement = call.receive<Announcement>()
            val id = announcementService.create(announcement)

            call.respond(HttpStatusCode.Created, id)
        }

        get("/announcements/{id}") {
            val id = call.parameters["id"]?.toInt()
                ?: throw IllegalArgumentException("Invalid ID")

            val announcement = announcementService.read(id)

            if (announcement != null) {
                call.respond(HttpStatusCode.OK, announcement)
            } else {
                call.respond(HttpStatusCode.NotFound)
            }
        }

        put("/announcements/{id}") {
            val id = call.parameters["id"]?.toInt()
                ?: throw IllegalArgumentException("Invalid ID")

            val announcement = call.receive<Announcement>()
            announcementService.update(id, announcement)

            call.respond(HttpStatusCode.NoContent)
        }

        delete("/announcements/{id}") {
            val id = call.parameters["id"]?.toInt()
                ?: throw IllegalArgumentException("Invalid ID")

            announcementService.delete(id)

            call.respond(HttpStatusCode.NoContent)
        }
        // EVENTS

        post("/events") {
            val event = call.receive<Event>()
            val id = eventService.create(event)

            call.respond(HttpStatusCode.Created, id)
        }

        get("/events/{id}") {
            val id = call.parameters["id"]?.toInt()
                ?: throw IllegalArgumentException("Invalid ID")

            val event = eventService.read(id)

            if (event != null) {
                call.respond(HttpStatusCode.OK, event)
            } else {
                call.respond(HttpStatusCode.NotFound)
            }
        }

        put("/events/{id}") {
            val id = call.parameters["id"]?.toInt()
                ?: throw IllegalArgumentException("Invalid ID")

            val event = call.receive<Event>()
            eventService.update(id, event)

            call.respond(HttpStatusCode.NoContent)
        }

        delete("/events/{id}") {
            val id = call.parameters["id"]?.toInt()
                ?: throw IllegalArgumentException("Invalid ID")

            eventService.delete(id)

            call.respond(HttpStatusCode.NoContent)
        }
        // GAMIFICATION PROFILES

        post("/gamification-profiles") {
            val profile = call.receive<GamificationProfile>()
            val id = gamificationProfileService.create(profile)

            call.respond(HttpStatusCode.Created, id)
        }

        get("/gamification-profiles/{id}") {
            val id = call.parameters["id"]?.toInt()
                ?: throw IllegalArgumentException("Invalid ID")

            val profile = gamificationProfileService.read(id)

            if (profile != null) {
                call.respond(HttpStatusCode.OK, profile)
            } else {
                call.respond(HttpStatusCode.NotFound)
            }
        }

        put("/gamification-profiles/{id}") {
            val id = call.parameters["id"]?.toInt()
                ?: throw IllegalArgumentException("Invalid ID")

            val profile = call.receive<GamificationProfile>()
            gamificationProfileService.update(id, profile)

            call.respond(HttpStatusCode.NoContent)
        }

        delete("/gamification-profiles/{id}") {
            val id = call.parameters["id"]?.toInt()
                ?: throw IllegalArgumentException("Invalid ID")

            gamificationProfileService.delete(id)

            call.respond(HttpStatusCode.NoContent)
        }
        // NOTIFICATION PREFERENCES
        post("/notification-preferences") {
            val preference = call.receive<NotificationPreference>()
            val id = notificationPreferencesService.create(preference)

            call.respond(HttpStatusCode.Created, id)
        }

        get("/notification-preferences/{id}") {
            val id = call.parameters["id"]?.toInt()
                ?: throw IllegalArgumentException("Invalid ID")

            val preference = notificationPreferencesService.read(id)

            if (preference != null) {
                call.respond(HttpStatusCode.OK, preference)
            } else {
                call.respond(HttpStatusCode.NotFound)
            }
        }

        put("/notification-preferences/{id}") {
            val id = call.parameters["id"]?.toInt()
                ?: throw IllegalArgumentException("Invalid ID")

            val preference = call.receive<NotificationPreference>()
            notificationPreferencesService.update(id, preference)

            call.respond(HttpStatusCode.NoContent)
        }

        delete("/notification-preferences/{id}") {
            val id = call.parameters["id"]?.toInt()
                ?: throw IllegalArgumentException("Invalid ID")

            notificationPreferencesService.delete(id)

            call.respond(HttpStatusCode.NoContent)
        }
    }
}