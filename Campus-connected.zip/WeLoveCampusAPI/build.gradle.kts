
plugins {
    alias(libs.plugins.kotlin.jvm)
    alias(ktorLibs.plugins.ktor)
    alias(libs.plugins.kotlin.serialization)
}

group = "org.welovecampus"
version = "1.0.0-SNAPSHOT"

application {
    mainClass = "io.ktor.server.netty.EngineMain"
}

kotlin {
    jvmToolchain(21)
}
dependencies {
    implementation(ktorLibs.serialization.kotlinx.json)
    implementation(ktorLibs.server.contentNegotiation)
    implementation(ktorLibs.server.core)
    implementation(ktorLibs.server.netty)
    implementation(ktorLibs.server.statusPages)

    implementation(libs.logback.classic)
    implementation(libs.exposed.core)
    implementation("org.jetbrains.exposed:exposed-jdbc:1.3.1")
    implementation("com.microsoft.sqlserver:mssql-jdbc:13.2.1.jre11")
    testImplementation(kotlin("test"))
    testImplementation(ktorLibs.server.testHost)
}
