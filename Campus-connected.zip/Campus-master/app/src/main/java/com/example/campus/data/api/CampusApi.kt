package com.example.campus.data.api

import com.example.campus.data.model.Announcement
import com.example.campus.data.model.CampusEvent
import com.example.campus.data.model.DeviceRegistration
import com.example.campus.data.model.RegistrationResponse
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Query

/**
 * Retrofit description of the We Love Campus REST API (Square, 2024).
 * Endpoint paths follow section 4.2 of the Part 1 design document.
 */
interface CampusApi {

    @GET("api/announcements")
    suspend fun getAnnouncements(@Query("category") category: String? = null): List<Announcement>

    @GET("api/events")
    suspend fun getEvents(): List<CampusEvent>

    @POST("api/notifications/register")
    suspend fun registerDevice(@Body body: DeviceRegistration): RegistrationResponse
}
