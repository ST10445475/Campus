package com.example.campus.data.repository

import com.example.campus.data.model.Discussion

/**
 * Supplies discussion data.
 *
 * Mock data is used until the REST API is available.
 */
class DiscussionRepository {

    suspend fun getDiscussions(): Result<List<Discussion>> {
        return Result.success(
            listOf(
                Discussion(
                    discussionId = "discussion-1",
                    moduleCode = "OPSC6311",
                    title = "Help with the Android project",
                    message = "Is anyone else having problems with Room Database?",
                    author = "Thando",
                    timestamp = System.currentTimeMillis() - 3_600_000,
                    replyCount = 4
                ),

                Discussion(
                    discussionId = "discussion-2",
                    moduleCode = "WEDE6021",
                    title = "Website submission requirements",
                    message = "Can someone clarify the final submission requirements?",
                    author = "Lerato",
                    timestamp = System.currentTimeMillis() - 7_200_000,
                    replyCount = 2
                ),

                Discussion(
                    discussionId = "discussion-3",
                    moduleCode = "DATA6222",
                    title = "Database revision discussion",
                    message = "Which database topics should we focus on for revision?",
                    author = "Mpho",
                    timestamp = System.currentTimeMillis() - 86_400_000,
                    replyCount = 6
                ),

                Discussion(
                    discussionId = "discussion-4",
                    moduleCode = "OPSC6311",
                    title = "Useful Kotlin resources",
                    message = "I found some helpful resources for learning Kotlin.",
                    author = "Sibongakonke",
                    timestamp = System.currentTimeMillis() - 172_800_000,
                    replyCount = 3
                )
            )
        )
    }
}