package com.example.campus.logic

import java.util.Calendar

/** Builds the month grid for the Events calendar. Pure Kotlin so it is unit tested. */
object CalendarLogic {

    /**
     * Monday-first grid. Each entry is a day number, or null for an empty cell
     * before day 1 / after the last day. The size is always a multiple of 7.
     */
    fun buildMonthGrid(month: MonthRef): List<Int?> {
        val first = Calendar.getInstance().apply {
            clear()
            set(month.year, month.month - 1, 1)
        }
        val daysInMonth = first.getActualMaximum(Calendar.DAY_OF_MONTH)
        // Calendar: Sunday = 1 ... Saturday = 7. This turns it into Monday = 0 ... Sunday = 6.
        val offset = (first.get(Calendar.DAY_OF_WEEK) + 5) % 7

        val cells = ArrayList<Int?>()
        repeat(offset) { cells.add(null) }
        for (d in 1..daysInMonth) cells.add(d)
        while (cells.size % 7 != 0) cells.add(null)
        return cells
    }
}
