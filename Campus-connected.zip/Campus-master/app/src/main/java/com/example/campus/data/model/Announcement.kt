package com.example.campus.data.model

/** Categories from the Part 1 design (section 6, Announcement entity). */
enum class AnnouncementCategory { Academic, Administrative, Emergency }

/**
 * One campus announcement. Field names match the JSON returned by GET /api/announcements
 * so Gson can map them without extra annotations.
 */
data class Announcement(
    val announcementId: String,
    val sender: String,              // e.g. Registrar, Library, IT Support
    val message: String,
    val category: AnnouncementCategory,
    val timestamp: Long              // epoch milliseconds
)
