package com.example.campus

/**
 * Central switches for the campus features (Person 5).
 *
 * USE_MOCK = true  -> screens run on built-in sample data (no server needed).
 * USE_MOCK = false -> screens call Person 1's REST API at BASE_URL.
 */
object AppConfig {
    const val USE_MOCK = false

    // Points at the WeLoveCampus API (Ktor server, connected to the Azure SQL database).
    //
    // - Running the API locally (./gradlew run, listens on port 8080) and testing on the
    //   Android EMULATOR: keep this as-is. 10.0.2.2 is the emulator's alias for your
    //   computer's localhost.
    // - Testing on a PHYSICAL device on the same Wi-Fi: replace with your computer's LAN
    //   IP, e.g. "http://192.168.1.23:8080/".
    // - Once the API is deployed (e.g. Azure App Service): replace with that HTTPS URL,
    //   e.g. "https://your-api.azurewebsites.net/". Must end with "/".
    const val BASE_URL = "http://10.0.2.2:8080/"
}
