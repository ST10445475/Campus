package com.example.campus.logic

import com.example.campus.data.model.CampusEvent

/** Event rules from Part 1, section 2.8. Pure Kotlin so it is unit tested. */
object EventLogic {

    /**
     * Upcoming list: past days are hidden automatically, today's events stay visible
     * all day, and the list is sorted soonest first.
     */
    fun upcoming(events: List<CampusEvent>, now: Long): List<CampusEvent> {
        val today = DayKey.fromMillis(now)
        return events
            .filter { DayKey.fromMillis(it.startTime) >= today }
            .sortedBy { it.startTime }
    }

    /** All events on one day (used when the student taps a date), earliest first. */
    fun onDay(events: List<CampusEvent>, day: DayKey): List<CampusEvent> =
        events
            .filter { DayKey.fromMillis(it.startTime) == day }
            .sortedBy { it.startTime }

    /** Day numbers in the shown month that have at least one event (gold cells). */
    fun daysWithEvents(events: List<CampusEvent>, month: MonthRef): Set<Int> =
        events
            .map { DayKey.fromMillis(it.startTime) }
            .filter { it.year == month.year && it.month == month.month }
            .map { it.day }
            .toSet()
}
