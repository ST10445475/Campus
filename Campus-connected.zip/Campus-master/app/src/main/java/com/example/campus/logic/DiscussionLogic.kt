package com.example.campus.logic

import com.example.campus.data.model.Discussion

/**
 * Contains rules for sorting and filtering discussions.
 */
object DiscussionLogic {

    /**
     * Displays the newest discussions first.
     */
    fun sortNewestFirst(
        discussions: List<Discussion>
    ): List<Discussion> {
        return discussions.sortedByDescending { it.timestamp }
    }

    /**
     * Filters discussions by module code.
     */
    fun filterByModule(
        discussions: List<Discussion>,
        moduleCode: String
    ): List<Discussion> {
        if (moduleCode == "All Modules") {
            return discussions
        }

        return discussions.filter {
            it.moduleCode == moduleCode
        }
    }

    /**
     * Returns the module codes available in the discussion list.
     */
    fun getModuleCodes(
        discussions: List<Discussion>
    ): List<String> {
        return listOf("All Modules") +
                discussions
                    .map { it.moduleCode }
                    .distinct()
                    .sorted()
    }
}