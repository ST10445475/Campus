package com.example.campus.notifications

/**
 * Decides whether a push may be shown. Pure Kotlin, so it is unit tested.
 * Part 1, sections 2.7 and 2.9: Emergency announcements are ALWAYS delivered and
 * cannot be switched off; every other category follows the student's toggle.
 */
object NotificationPolicy {

    fun shouldDeliver(
        category: NotificationCategory,
        isEmergency: Boolean,
        isEnabled: (prefKey: String) -> Boolean
    ): Boolean {
        if (isEmergency && category == NotificationCategory.ANNOUNCEMENTS) return true
        return isEnabled(category.prefKey)
    }
}
