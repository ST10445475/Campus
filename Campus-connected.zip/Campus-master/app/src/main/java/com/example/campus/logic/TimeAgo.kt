package com.example.campus.logic

enum class AgoUnit { JUST_NOW, MINUTES, HOURS, DAYS }

/**
 * Pure "how long ago" calculation (no Android code, so it is easy to unit test).
 * The UI turns this into text using string resources, which keeps it translatable
 * into isiZulu, isiXhosa, Afrikaans and Sesotho.
 */
data class TimeAgo(val unit: AgoUnit, val value: Long) {
    companion object {
        fun from(now: Long, then: Long): TimeAgo {
            // A timestamp in the future (clock drift) is treated as "just now"
            val minutes = (now - then).coerceAtLeast(0L) / 60_000L
            return when {
                minutes < 1 -> TimeAgo(AgoUnit.JUST_NOW, 0)
                minutes < 60 -> TimeAgo(AgoUnit.MINUTES, minutes)
                minutes < 24 * 60 -> TimeAgo(AgoUnit.HOURS, minutes / 60)
                else -> TimeAgo(AgoUnit.DAYS, minutes / (24 * 60))
            }
        }
    }
}
