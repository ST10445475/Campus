package com.example.campus.ui.announcements

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.campus.AppConfig
import com.example.campus.R
import com.example.campus.SettingsActivity
import com.example.campus.data.repository.RepositoryProvider
import com.example.campus.logic.AnnouncementLogic
import com.example.campus.notifications.FcmTokenManager
import com.example.campus.notifications.NotificationCategory
import com.example.campus.notifications.NotificationHelper
import kotlinx.coroutines.launch

/**
 * Campus Announcements feed (Part 1, section 2.7).
 * Loads through AnnouncementRepository, so it works on mock data now and on
 * Person 1's API later. Errors are shown on screen instead of crashing the app.
 */
class AnnouncementsActivity : AppCompatActivity() {

    private lateinit var adapter: AnnouncementAdapter
    private lateinit var list: RecyclerView
    private lateinit var progress: ProgressBar
    private lateinit var statePanel: View
    private lateinit var stateText: TextView

    // Android 13+ needs the student's permission before notifications can be shown
    private val notificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            Log.d(TAG, "POST_NOTIFICATIONS granted = $granted")
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge() // same as Person 2's MainActivity; the app targets SDK 36 (edge-to-edge)
        setContentView(R.layout.activity_announcements)
        applySystemBarPadding()

        list = findViewById(R.id.announcementList)
        progress = findViewById(R.id.progress)
        statePanel = findViewById(R.id.statePanel)
        stateText = findViewById(R.id.stateText)

        adapter = AnnouncementAdapter()
        list.layoutManager = LinearLayoutManager(this)
        list.adapter = adapter

        findViewById<Button>(R.id.btnRetry).setOnClickListener { loadAnnouncements() }
        setUpDemoButtons()

        // TODO: move these two calls to the Dashboard / first launch once screens are merged
        requestNotificationPermissionIfNeeded()
        FcmTokenManager.sync(this)

        loadAnnouncements()
    }

    /**
     * Keeps the red header below the status bar and the buttons above the navigation bar
     * (same idea as MainActivity's window-insets listener).
     */
    private fun applySystemBarPadding() {
        val root = findViewById<View>(R.id.announcementsRoot)
        val header = findViewById<View>(R.id.header)
        val headerTopPadding = header.paddingTop
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(bars.left, 0, bars.right, bars.bottom)
            header.setPadding(
                header.paddingLeft,
                headerTopPadding + bars.top,
                header.paddingRight,
                header.paddingBottom
            )
            insets
        }
    }

    private fun loadAnnouncements() {
        showLoading()
        lifecycleScope.launch {
            RepositoryProvider.announcements(this@AnnouncementsActivity)
                .getAnnouncements()
                .onSuccess { items ->
                    val sorted = AnnouncementLogic.sortNewestFirst(items)
                    Log.d(TAG, "Showing ${sorted.size} announcements")
                    if (sorted.isEmpty()) {
                        showMessage(getString(R.string.announcements_empty), showRetry = false)
                    } else {
                        adapter.submitList(sorted)
                        showList()
                    }
                }
                .onFailure { error ->
                    Log.e(TAG, "Could not load announcements", error)
                    showMessage(getString(R.string.common_error_generic), showRetry = true)
                }
        }
    }

    // --- Screen states ------------------------------------------------------------------

    private fun showLoading() {
        progress.visibility = View.VISIBLE
        list.visibility = View.GONE
        statePanel.visibility = View.GONE
    }

    private fun showList() {
        progress.visibility = View.GONE
        statePanel.visibility = View.GONE
        list.visibility = View.VISIBLE
    }

    private fun showMessage(text: String, showRetry: Boolean) {
        progress.visibility = View.GONE
        list.visibility = View.GONE
        stateText.text = text
        findViewById<Button>(R.id.btnRetry).visibility = if (showRetry) View.VISIBLE else View.GONE
        statePanel.visibility = View.VISIBLE
    }

    // --- Demo helpers (only visible while AppConfig.USE_MOCK = true) ---------------------

    private fun setUpDemoButtons() {
        val panel = findViewById<View>(R.id.demoPanel)
        panel.visibility = if (AppConfig.USE_MOCK) View.VISIBLE else View.GONE

        findViewById<Button>(R.id.btnDemoEmergency).setOnClickListener {
            val shown = NotificationHelper.show(
                this, NotificationCategory.ANNOUNCEMENTS,
                getString(R.string.demo_emergency_title),
                getString(R.string.demo_emergency_body),
                isEmergency = true
            )
            if (!shown) Toast.makeText(this, R.string.demo_not_shown, Toast.LENGTH_LONG).show()
        }
        findViewById<Button>(R.id.btnDemoNormal).setOnClickListener {
            val shown = NotificationHelper.show(
                this, NotificationCategory.ANNOUNCEMENTS,
                getString(R.string.demo_normal_title),
                getString(R.string.demo_normal_body),
                isEmergency = false
            )
            if (!shown) Toast.makeText(this, R.string.demo_not_shown, Toast.LENGTH_LONG).show()
        }
        // Opens Person 2's Settings screen so the notification toggles can be tested from here
        findViewById<Button>(R.id.btnDemoSettings).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    companion object {
        private const val TAG = "AnnouncementsActivity"
    }
}
