package com.example.campus.ui.discussions

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.campus.R
import com.example.campus.data.model.Discussion
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Displays discussion topics in a RecyclerView.
 */
class DiscussionAdapter :
    ListAdapter<Discussion, DiscussionAdapter.ViewHolder>(DIFF) {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val moduleCode: TextView = view.findViewById(R.id.txtModuleCode)
        val title: TextView = view.findViewById(R.id.txtDiscussionTitle)
        val message: TextView = view.findViewById(R.id.txtDiscussionMessage)
        val author: TextView = view.findViewById(R.id.txtDiscussionAuthor)
        val replyCount: TextView = view.findViewById(R.id.txtReplyCount)
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_discussion, parent, false)

        return ViewHolder(view)
    }

    override fun onBindViewHolder(
        holder: ViewHolder,
        position: Int
    ) {
        val discussion = getItem(position)

        holder.moduleCode.text = discussion.moduleCode
        holder.title.text = discussion.title
        holder.message.text = discussion.message
        holder.author.text = "Posted by ${discussion.author}"

        holder.replyCount.text = if (discussion.replyCount == 1) {
            "1 reply"
        } else {
            "${discussion.replyCount} replies"
        }
    }

    companion object {
        private val DIFF = object : DiffUtil.ItemCallback<Discussion>() {

            override fun areItemsTheSame(
                oldItem: Discussion,
                newItem: Discussion
            ): Boolean {
                return oldItem.discussionId == newItem.discussionId
            }

            override fun areContentsTheSame(
                oldItem: Discussion,
                newItem: Discussion
            ): Boolean {
                return oldItem == newItem
            }
        }
    }
}