package com.example.campus.ui.events

import android.os.Bundle
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.campus.AppConfig
import com.example.campus.R
import com.example.campus.data.model.CampusEvent
import com.example.campus.data.repository.RepositoryProvider
import com.example.campus.logic.DayKey
import com.example.campus.logic.CalendarLogic
import com.example.campus.logic.EventLogic
import com.example.campus.logic.MonthRef
import com.example.campus.notifications.NotificationCategory
import com.example.campus.notifications.NotificationHelper
import com.example.campus.ui.common.InsetsHelper
import kotlinx.coroutines.launch
import java.text.DateFormatSymbols
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date

/**
 * Event Calendar (Part 1, section 2.8): monthly grid with event days highlighted,
 * tap a date to see that day's events, and an "Upcoming" list that hides past events.
 */
class EventsActivity : AppCompatActivity() {

    private lateinit var content: View
    private lateinit var progress: ProgressBar
    private lateinit var statePanel: View
    private lateinit var stateText: TextView
    private lateinit var monthTitle: TextView
    private lateinit var listTitle: TextView
    private lateinit var emptyText: TextView

    private lateinit var calendarAdapter: CalendarAdapter
    private lateinit var eventAdapter: EventAdapter

    private var allEvents: List<CampusEvent> = emptyList()
    private var shownMonth: MonthRef = MonthRef.of(DayKey.fromMillis(System.currentTimeMillis()))
    private var selectedDay: DayKey? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_events)
        InsetsHelper.applyHeaderInsets(findViewById(R.id.eventsRoot), findViewById(R.id.header))

        content = findViewById(R.id.eventsContent)
        progress = findViewById(R.id.progress)
        statePanel = findViewById(R.id.statePanel)
        stateText = findViewById(R.id.stateText)
        monthTitle = findViewById(R.id.txtMonthTitle)
        listTitle = findViewById(R.id.txtListTitle)
        emptyText = findViewById(R.id.txtEmpty)

        buildWeekdayHeader()

        calendarAdapter = CalendarAdapter { day -> onDayClicked(day) }
        findViewById<RecyclerView>(R.id.calendarGrid).apply {
            layoutManager = GridLayoutManager(this@EventsActivity, 7)
            adapter = calendarAdapter
        }

        eventAdapter = EventAdapter()
        findViewById<RecyclerView>(R.id.eventList).apply {
            layoutManager = LinearLayoutManager(this@EventsActivity)
            adapter = eventAdapter
        }

        findViewById<View>(R.id.btnPrevMonth).setOnClickListener { changeMonth(shownMonth.previous()) }
        findViewById<View>(R.id.btnNextMonth).setOnClickListener { changeMonth(shownMonth.next()) }
        findViewById<Button>(R.id.btnRetry).setOnClickListener { loadEvents() }
        setUpDemoButton()

        loadEvents()
    }

    private fun loadEvents() {
        showLoading()
        lifecycleScope.launch {
            RepositoryProvider.events(this@EventsActivity)
                .getEvents()
                .onSuccess { events ->
                    Log.d(TAG, "Loaded ${events.size} events")
                    allEvents = events
                    showContent()
                    render()
                }
                .onFailure { error ->
                    Log.e(TAG, "Could not load events", error)
                    showMessage(getString(R.string.common_error_generic))
                }
        }
    }

    // --- Interaction --------------------------------------------------------------------

    private fun onDayClicked(day: Int) {
        val clicked = DayKey(shownMonth.year, shownMonth.month, day)
        // Tapping the selected date again clears the selection (back to "Upcoming")
        selectedDay = if (selectedDay == clicked) null else clicked
        Log.d(TAG, "Selected day = $selectedDay")
        render()
    }

    private fun changeMonth(month: MonthRef) {
        shownMonth = month
        selectedDay = null
        Log.d(TAG, "Showing month ${month.year}-${month.month}")
        render()
    }

    // --- Drawing ------------------------------------------------------------------------

    /** Redraws the month title, the calendar grid and the event list from current state. */
    private fun render() {
        val locale = resources.configuration.locales[0]
        val now = System.currentTimeMillis()

        monthTitle.text = SimpleDateFormat("MMMM yyyy", locale).format(monthStart(shownMonth))

        val today = DayKey.fromMillis(now)
        val eventDays = EventLogic.daysWithEvents(allEvents, shownMonth)
        val cells = CalendarLogic.buildMonthGrid(shownMonth).map { day ->
            DayCell(
                day = day,
                hasEvent = day != null && day in eventDays,
                isToday = day != null && today == DayKey(shownMonth.year, shownMonth.month, day),
                isSelected = day != null && selectedDay == DayKey(shownMonth.year, shownMonth.month, day)
            )
        }
        calendarAdapter.submit(cells)

        val selected = selectedDay
        val items: List<CampusEvent>
        if (selected == null) {
            listTitle.text = getString(R.string.events_upcoming)
            items = EventLogic.upcoming(allEvents, now)
            emptyText.setText(R.string.events_none_upcoming)
        } else {
            val dayText = SimpleDateFormat("d MMM", locale).format(dayStart(selected))
            listTitle.text = getString(R.string.events_on_day, dayText)
            items = EventLogic.onDay(allEvents, selected)
            emptyText.setText(R.string.events_none_day)
        }
        eventAdapter.submitList(items)
        emptyText.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun monthStart(month: MonthRef): Date =
        Calendar.getInstance().apply { clear(); set(month.year, month.month - 1, 1) }.time

    private fun dayStart(day: DayKey): Date =
        Calendar.getInstance().apply { clear(); set(day.year, day.month - 1, day.day) }.time

    /** Mon..Sun labels in the app's current language. */
    private fun buildWeekdayHeader() {
        val row = findViewById<LinearLayout>(R.id.weekdayRow)
        val locale = resources.configuration.locales[0]
        val names = DateFormatSymbols.getInstance(locale).shortWeekdays // index 1 = Sunday
        val mondayFirst = listOf(
            Calendar.MONDAY, Calendar.TUESDAY, Calendar.WEDNESDAY, Calendar.THURSDAY,
            Calendar.FRIDAY, Calendar.SATURDAY, Calendar.SUNDAY
        )
        for (weekday in mondayFirst) {
            val label = TextView(this).apply {
                text = names[weekday]
                gravity = Gravity.CENTER
                textSize = 12f
                setTextColor(ContextCompat.getColor(context, R.color.campus_text_muted))
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            }
            row.addView(label)
        }
    }

    // --- Screen states ------------------------------------------------------------------

    private fun showLoading() {
        progress.visibility = View.VISIBLE
        content.visibility = View.GONE
        statePanel.visibility = View.GONE
    }

    private fun showContent() {
        progress.visibility = View.GONE
        statePanel.visibility = View.GONE
        content.visibility = View.VISIBLE
    }

    private fun showMessage(text: String) {
        progress.visibility = View.GONE
        content.visibility = View.GONE
        stateText.text = text
        statePanel.visibility = View.VISIBLE
    }

    // --- Demo helper (only visible while AppConfig.USE_MOCK = true) -----------------------

    private fun setUpDemoButton() {
        findViewById<View>(R.id.demoPanel).visibility =
            if (AppConfig.USE_MOCK) View.VISIBLE else View.GONE

        findViewById<Button>(R.id.btnDemoEvent).setOnClickListener {
            val shown = NotificationHelper.show(
                this, NotificationCategory.EVENTS,
                getString(R.string.demo_event_title),
                getString(R.string.demo_event_body),
                isEmergency = false
            )
            if (!shown) Toast.makeText(this, R.string.demo_not_shown, Toast.LENGTH_LONG).show()
        }
    }

    companion object {
        private const val TAG = "EventsActivity"
    }
}
