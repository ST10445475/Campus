package com.example.campus.ui.events

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.example.campus.R

/** One square in the month grid. day == null means an empty cell. */
data class DayCell(
    val day: Int?,
    val hasEvent: Boolean,
    val isToday: Boolean,
    val isSelected: Boolean
)

/**
 * Draws the month grid (7 columns). Gold = has an event, crimson = selected,
 * crimson outline = today. The list is at most 42 cells, so a full refresh is fine.
 */
class CalendarAdapter(private val onDayClick: (Int) -> Unit) :
    RecyclerView.Adapter<CalendarAdapter.ViewHolder>() {

    private var cells: List<DayCell> = emptyList()

    fun submit(newCells: List<DayCell>) {
        cells = newCells
        notifyDataSetChanged()
    }

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val text: TextView = view.findViewById(R.id.txtDay)
    }

    override fun getItemCount(): Int = cells.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_calendar_day, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val cell = cells[position]
        val day = cell.day
        val text = holder.text
        val context = text.context

        if (day == null) { // empty cell before day 1 / after the last day
            text.text = ""
            text.background = null
            text.setOnClickListener(null)
            text.isClickable = false
            return
        }

        val crimson = ContextCompat.getColor(context, R.color.campus_crimson)
        val gold = ContextCompat.getColor(context, R.color.campus_gold)
        val dark = ContextCompat.getColor(context, R.color.campus_text_dark)

        val fill: Int? = when {
            cell.isSelected -> crimson
            cell.hasEvent -> gold
            else -> null
        }
        val stroke: Int? = if (cell.isToday && !cell.isSelected) crimson else null

        text.text = day.toString()
        text.setTextColor(if (cell.isSelected) Color.WHITE else dark)
        text.setTypeface(null, if (cell.isToday) Typeface.BOLD else Typeface.NORMAL)
        text.background = if (fill != null || stroke != null) makeBackground(context, fill, stroke) else null
        text.isClickable = true
        text.setOnClickListener { onDayClick(day) }
    }

    private fun makeBackground(context: Context, fill: Int?, stroke: Int?): GradientDrawable {
        val density = context.resources.displayMetrics.density
        return GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = 8 * density
            setColor(fill ?: Color.TRANSPARENT)
            if (stroke != null) setStroke((2 * density).toInt(), stroke)
        }
    }
}
