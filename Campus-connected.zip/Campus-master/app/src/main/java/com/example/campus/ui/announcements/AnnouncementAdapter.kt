package com.example.campus.ui.announcements

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.campus.R
import com.example.campus.data.model.Announcement
import com.example.campus.logic.AgoUnit
import com.example.campus.logic.AnnouncementLogic
import com.example.campus.logic.TimeAgo
import com.google.android.material.card.MaterialCardView

/** Shows announcements in a RecyclerView using ListAdapter + DiffUtil (Android Developers, 2026c). */
class AnnouncementAdapter :
    ListAdapter<Announcement, AnnouncementAdapter.ViewHolder>(DIFF) {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val card: MaterialCardView = view.findViewById(R.id.announcementCard)
        val emergencyRow: View = view.findViewById(R.id.emergencyRow)
        val sender: TextView = view.findViewById(R.id.txtSender)
        val message: TextView = view.findViewById(R.id.txtMessage)
        val time: TextView = view.findViewById(R.id.txtTime)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_announcement, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = getItem(position)
        val context = holder.itemView.context
        val emergency = AnnouncementLogic.isEmergency(item)

        holder.sender.text = item.sender
        holder.message.text = item.message
        holder.time.text = formatAgo(context, TimeAgo.from(System.currentTimeMillis(), item.timestamp))

        // Emergency announcements are visually distinct: red tint, red border, icon + label
        holder.emergencyRow.visibility = if (emergency) View.VISIBLE else View.GONE
        holder.card.setCardBackgroundColor(
            ContextCompat.getColor(context, if (emergency) R.color.campus_emergency_bg else R.color.campus_cream)
        )
        holder.card.strokeColor =
            ContextCompat.getColor(context, if (emergency) R.color.campus_crimson else R.color.campus_border)
        val density = context.resources.displayMetrics.density
        holder.card.strokeWidth = ((if (emergency) 2 else 1) * density).toInt()
    }

    private fun formatAgo(context: Context, ago: TimeAgo): String = when (ago.unit) {
        AgoUnit.JUST_NOW -> context.getString(R.string.time_just_now)
        AgoUnit.MINUTES -> context.getString(R.string.time_minutes_ago, ago.value)
        AgoUnit.HOURS -> context.getString(R.string.time_hours_ago, ago.value)
        AgoUnit.DAYS -> context.getString(R.string.time_days_ago, ago.value)
    }

    companion object {
        private val DIFF = object : DiffUtil.ItemCallback<Announcement>() {
            override fun areItemsTheSame(oldItem: Announcement, newItem: Announcement) =
                oldItem.announcementId == newItem.announcementId

            override fun areContentsTheSame(oldItem: Announcement, newItem: Announcement) =
                oldItem == newItem
        }
    }
}
