package com.example.campus.data.model

/**
 * Represents a discussion topic created by a student or staff member.
 *
 * The structure can be connected to the Discussions REST API later.
 */
data class Discussion(
    val discussionId: String,
    val moduleCode: String,
    val title: String,
    val message: String,
    val author: String,
    val timestamp: Long,
    val replyCount: Int
)