package com.example.campus.notifications

/**
 * The five notification categories from the Part 1 design (section 2.9).
 * prefKey  = key Person 2 saves in the "settings" SharedPreferences (SettingsActivity).
 * fcmValue = value the server puts in the push payload's "category" field.
 */
enum class NotificationCategory(val prefKey: String, val fcmValue: String) {
    ASSIGNMENTS("notif_assignments", "assignments"),
    TIMETABLE("notif_timetable", "timetable"),
    ANNOUNCEMENTS("notif_announcements", "announcements"),
    EVENTS("notif_events", "events"),
    DISCUSSIONS("notif_discussions", "discussions");

    companion object {
        /** Returns null for an unknown/missing value so a bad payload never crashes the app. */
        fun fromFcm(value: String?): NotificationCategory? =
            values().firstOrNull { it.fcmValue == value }
    }
}
