package com.example.campus.data.model

/**
 * One campus event (career fair, hackathon, orientation...). Matches GET /api/events.
 * startTime is epoch milliseconds so date AND time travel in one field.
 */
data class CampusEvent(
    val eventId: String,
    val title: String,
    val startTime: Long,
    val location: String
)
