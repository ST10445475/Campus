package com.example.campus.data.repository

import android.util.Log
import com.example.campus.data.api.CampusApi
import com.example.campus.data.model.DeviceRegistration
import com.example.campus.data.model.RegistrationResponse
import kotlinx.coroutines.CancellationException

/** Registers this phone's FCM token (and notification choices) with the API. */
interface DeviceRepository {
    suspend fun register(registration: DeviceRegistration): Result<RegistrationResponse>
}

class MockDeviceRepository : DeviceRepository {
    override suspend fun register(registration: DeviceRegistration): Result<RegistrationResponse> {
        Log.d("MockDeviceRepo", "Pretending to register device. Preferences: ${registration.preferences}")
        return Result.success(RegistrationResponse(true, "mock"))
    }
}

class RemoteDeviceRepository(private val api: CampusApi) : DeviceRepository {
    override suspend fun register(registration: DeviceRegistration): Result<RegistrationResponse> = try {
        val response = api.registerDevice(registration)
        Log.d("RemoteDeviceRepo", "Device registered: success=${response.success}")
        Result.success(response)
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        Log.e("RemoteDeviceRepo", "Device registration failed", e)
        Result.failure(e)
    }
}
