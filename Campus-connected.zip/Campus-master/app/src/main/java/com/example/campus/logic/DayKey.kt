package com.example.campus.logic

import java.util.Calendar
import java.util.TimeZone

/**
 * A calendar day with no time attached (month is 1..12).
 * Own small class instead of java.time, because the app supports Android 7 (API 24).
 */
data class DayKey(val year: Int, val month: Int, val day: Int) : Comparable<DayKey> {

    override fun compareTo(other: DayKey): Int =
        compareValuesBy(this, other, DayKey::year, DayKey::month, DayKey::day)

    companion object {
        fun fromMillis(millis: Long, timeZone: TimeZone = TimeZone.getDefault()): DayKey {
            val c = Calendar.getInstance(timeZone).apply { timeInMillis = millis }
            return DayKey(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH))
        }
    }
}

/** A month shown on the calendar (month is 1..12). */
data class MonthRef(val year: Int, val month: Int) {
    fun next(): MonthRef = if (month == 12) MonthRef(year + 1, 1) else MonthRef(year, month + 1)
    fun previous(): MonthRef = if (month == 1) MonthRef(year - 1, 12) else MonthRef(year, month - 1)

    companion object {
        fun of(day: DayKey) = MonthRef(day.year, day.month)
    }
}
