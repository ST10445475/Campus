package com.example.campus.logic

import com.example.campus.data.model.Announcement
import com.example.campus.data.model.AnnouncementCategory

/** Announcement rules kept separate from the screen so they can be unit tested. */
object AnnouncementLogic {

    /** Part 1, section 2.7: feed is reverse-chronological (newest first). */
    fun sortNewestFirst(items: List<Announcement>): List<Announcement> =
        items.sortedByDescending { it.timestamp }

    /** Emergency announcements get a different colour and icon in the feed. */
    fun isEmergency(item: Announcement): Boolean =
        item.category == AnnouncementCategory.Emergency
}
