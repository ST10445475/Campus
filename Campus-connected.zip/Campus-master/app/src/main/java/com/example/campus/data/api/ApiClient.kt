package com.example.campus.data.api

import android.content.Context
import android.util.Log
import com.example.campus.AppConfig
import com.example.campus.SessionManager
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

/**
 * Builds one shared Retrofit client (Square, 2024).
 * Every request carries the signed-in student's token from Person 2's SessionManager.
 */
object ApiClient {
    private const val TAG = "ApiClient"

    @Volatile
    private var api: CampusApi? = null

    fun get(context: Context): CampusApi {
        return api ?: synchronized(this) {
            api ?: build(context.applicationContext).also { api = it }
        }
    }

    private fun build(appContext: Context): CampusApi {
        val session = SessionManager(appContext)

        // Adds "Authorization: Bearer <token>" to every call. Token is read fresh each time.
        val authInterceptor = Interceptor { chain ->
            val token = session.idToken()
            val request = chain.request().newBuilder()
                .apply { if (token.isNotEmpty()) addHeader("Authorization", "Bearer $token") }
                .build()
            chain.proceed(request)
        }

        // BASIC logs method, URL and status only. BODY/HEADERS would print the auth token.
        val logging = HttpLoggingInterceptor { message -> Log.d(TAG, message) }
            .apply { level = HttpLoggingInterceptor.Level.BASIC }

        val client = OkHttpClient.Builder()
            .addInterceptor(authInterceptor)
            .addInterceptor(logging)
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(15, TimeUnit.SECONDS)
            .build()

        Log.d(TAG, "Creating Retrofit client for ${AppConfig.BASE_URL}")
        return Retrofit.Builder()
            .baseUrl(AppConfig.BASE_URL)
            .client(client)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(CampusApi::class.java)
    }
}
