package com.example.campus.ui.hub

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.example.campus.R
import com.example.campus.SettingsActivity
import com.example.campus.ui.announcements.AnnouncementsActivity
import com.example.campus.ui.common.InsetsHelper
import com.example.campus.ui.events.EventsActivity

/**
 * The "More" hub: one place to open the campus screens.
 * TEMPORARY until the group's bottom-navigation "More" tab exists; that tab should
 * simply start this activity.
 */
class CampusHubActivity : AppCompatActivity() {

    private class Entry(val labelRes: Int, val target: Class<*>)

    private val notificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            Log.d(TAG, "POST_NOTIFICATIONS granted = $granted")
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_hub)
        InsetsHelper.applyHeaderInsets(findViewById(R.id.hubRoot), findViewById(R.id.header))

        // Add one line here for each new screen (Discussions and Achievements come later)
        val entries = listOf(
            Entry(R.string.announcements_title, AnnouncementsActivity::class.java),
            Entry(R.string.events_title, EventsActivity::class.java),
            Entry(R.string.hub_settings, SettingsActivity::class.java)
        )

        val list = findViewById<LinearLayout>(R.id.hubList)
        val margin = (12 * resources.displayMetrics.density).toInt()
        for (entry in entries) {
            val button = Button(this).apply {
                text = getString(entry.labelRes)
                setOnClickListener {
                    Log.d(TAG, "Opening ${entry.target.simpleName}")
                    startActivity(Intent(this@CampusHubActivity, entry.target))
                }
            }
            val params = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { setMargins(margin, margin / 2, margin, margin / 2) }
            list.addView(button, params)
        }

        // Android 13+ needs the student's permission before notifications can be shown
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    companion object {
        private const val TAG = "CampusHubActivity"
    }
}
