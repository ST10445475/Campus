package com.example.campus.notifications

import android.content.Context
import android.util.Log
import com.example.campus.data.model.DeviceRegistration
import com.example.campus.data.repository.RepositoryProvider
import com.google.firebase.messaging.FirebaseMessaging
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * Gets this phone's FCM token and registers it, together with the student's
 * notification choices, via POST /api/notifications/register.
 * Call sync() once the student is signed in (e.g. from the Dashboard).
 */
object FcmTokenManager {
    private const val TAG = "FcmTokenManager"
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    fun sync(context: Context) {
        val appContext = context.applicationContext
        try {
            FirebaseMessaging.getInstance().token.addOnCompleteListener { task ->
                if (!task.isSuccessful) {
                    Log.w(TAG, "Fetching FCM token failed", task.exception)
                    return@addOnCompleteListener
                }
                register(appContext, task.result)
            }
        } catch (e: IllegalStateException) {
            // Happens when google-services.json has not been added yet. App keeps working.
            Log.w(TAG, "Firebase is not configured yet (google-services.json missing?)", e)
        }
    }

    fun register(context: Context, token: String) {
        val settings = context.getSharedPreferences("settings", Context.MODE_PRIVATE)
        val preferences = NotificationCategory.values()
            .associate { it.prefKey to settings.getBoolean(it.prefKey, true) }
        val registration = DeviceRegistration(token, preferences)

        scope.launch {
            RepositoryProvider.devices(context).register(registration)
                .onSuccess { Log.d(TAG, "Device registered with server") }
                .onFailure { Log.e(TAG, "Could not register device", it) }
        }
    }
}
