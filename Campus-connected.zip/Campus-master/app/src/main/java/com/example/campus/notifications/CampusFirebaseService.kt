package com.example.campus.notifications

import android.util.Log
import com.example.campus.R
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

/**
 * Receives Firebase Cloud Messaging pushes (Firebase, 2026).
 *
 * IMPORTANT for Person 1: the server must send DATA-ONLY messages (no "notification" block).
 * A message with a "notification" block is shown by Android itself while the app is in the
 * background, which would bypass the student's notification toggles.
 *
 * Expected data payload:
 *   { "category": "announcements", "title": "...", "body": "...", "isEmergency": "true" }
 */
class CampusFirebaseService : FirebaseMessagingService() {

    override fun onNewToken(token: String) {
        super.onNewToken(token)
        Log.d(TAG, "New FCM token issued (${token.take(8)}...)")
        FcmTokenManager.register(applicationContext, token)
    }

    override fun onMessageReceived(message: RemoteMessage) {
        super.onMessageReceived(message)
        val data = message.data

        val category = NotificationCategory.fromFcm(data["category"])
        if (category == null) {
            Log.w(TAG, "Ignoring push with unknown category: ${data["category"]}")
            return
        }

        val title = data["title"] ?: message.notification?.title ?: getString(R.string.app_name)
        val body = data["body"] ?: message.notification?.body ?: ""
        val isEmergency = data["isEmergency"].equals("true", ignoreCase = true)

        Log.d(TAG, "Push received: category=${category.fcmValue}, emergency=$isEmergency")
        NotificationHelper.show(applicationContext, category, title, body, isEmergency)
    }

    companion object {
        private const val TAG = "CampusFirebaseService"
    }
}
