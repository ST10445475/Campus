package com.example.campus.ui.discussions

import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ProgressBar
import android.widget.Spinner
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.campus.R
import com.example.campus.data.model.Discussion
import com.example.campus.data.repository.DiscussionRepository
import com.example.campus.logic.DiscussionLogic
import kotlinx.coroutines.launch

/**
 * Displays module-specific campus discussions.
 */
class DiscussionsActivity : AppCompatActivity() {

    private lateinit var adapter: DiscussionAdapter
    private lateinit var discussionList: RecyclerView
    private lateinit var progress: ProgressBar
    private lateinit var statePanel: View
    private lateinit var stateText: TextView
    private lateinit var moduleSpinner: Spinner

    private var allDiscussions: List<Discussion> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        enableEdgeToEdge()
        setContentView(R.layout.activity_discussions)
        applySystemBarPadding()

        discussionList = findViewById(R.id.discussionList)
        progress = findViewById(R.id.progress)
        statePanel = findViewById(R.id.statePanel)
        stateText = findViewById(R.id.stateText)
        moduleSpinner = findViewById(R.id.moduleSpinner)

        adapter = DiscussionAdapter()

        discussionList.layoutManager = LinearLayoutManager(this)
        discussionList.adapter = adapter

        findViewById<Button>(R.id.btnRetry).setOnClickListener {
            loadDiscussions()
        }

        moduleSpinner.onItemSelectedListener =
            object : android.widget.AdapterView.OnItemSelectedListener {

                override fun onItemSelected(
                    parent: android.widget.AdapterView<*>?,
                    view: View?,
                    position: Int,
                    id: Long
                ) {
                    if (allDiscussions.isNotEmpty()) {
                        val selectedModule = moduleSpinner.selectedItem.toString()
                        filterDiscussions(selectedModule)
                    }
                }

                override fun onNothingSelected(
                    parent: android.widget.AdapterView<*>?
                ) {
                    // No action required.
                }
            }

        loadDiscussions()
    }

    private fun applySystemBarPadding() {
        val root = findViewById<View>(R.id.discussionsRoot)
        val header = findViewById<View>(R.id.header)
        val headerTopPadding = header.paddingTop

        ViewCompat.setOnApplyWindowInsetsListener(root) { view, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())

            view.setPadding(bars.left, 0, bars.right, bars.bottom)

            header.setPadding(
                header.paddingLeft,
                headerTopPadding + bars.top,
                header.paddingRight,
                header.paddingBottom
            )

            insets
        }
    }

    private fun loadDiscussions() {
        showLoading()

        lifecycleScope.launch {
            DiscussionRepository()
                .getDiscussions()
                .onSuccess { discussions ->
                    allDiscussions =
                        DiscussionLogic.sortNewestFirst(discussions)

                    val modules =
                        DiscussionLogic.getModuleCodes(allDiscussions)

                    val spinnerAdapter = ArrayAdapter(
                        this@DiscussionsActivity,
                        android.R.layout.simple_spinner_item,
                        modules
                    )

                    spinnerAdapter.setDropDownViewResource(
                        android.R.layout.simple_spinner_dropdown_item
                    )

                    moduleSpinner.adapter = spinnerAdapter

                    filterDiscussions("All Modules")
                }
                .onFailure {
                    showMessage("Unable to load discussions.", true)
                }
        }
    }

    private fun filterDiscussions(moduleCode: String) {
        val filtered = DiscussionLogic.filterByModule(
            allDiscussions,
            moduleCode
        )

        if (filtered.isEmpty()) {
            showMessage("No discussions found for this module.", false)
        } else {
            adapter.submitList(filtered)
            showList()
        }
    }

    private fun showLoading() {
        progress.visibility = View.VISIBLE
        discussionList.visibility = View.GONE
        statePanel.visibility = View.GONE
    }

    private fun showList() {
        progress.visibility = View.GONE
        statePanel.visibility = View.GONE
        discussionList.visibility = View.VISIBLE
    }

    private fun showMessage(
        message: String,
        showRetry: Boolean
    ) {
        progress.visibility = View.GONE
        discussionList.visibility = View.GONE
        stateText.text = message

        findViewById<Button>(R.id.btnRetry).visibility =
            if (showRetry) View.VISIBLE else View.GONE

        statePanel.visibility = View.VISIBLE
    }
}