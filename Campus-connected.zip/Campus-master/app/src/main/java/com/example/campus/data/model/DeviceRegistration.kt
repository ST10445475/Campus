package com.example.campus.data.model

/**
 * Body for POST /api/notifications/register (Part 1 design, section 4.2):
 * the device's FCM token plus the student's per-category notification choices.
 */
data class DeviceRegistration(
    val fcmToken: String,
    val preferences: Map<String, Boolean>
)

/** Confirmation returned by the API after registering a device. */
data class RegistrationResponse(
    val success: Boolean = true,
    val message: String? = null
)
