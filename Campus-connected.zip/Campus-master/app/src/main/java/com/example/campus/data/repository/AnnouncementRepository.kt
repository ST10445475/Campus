package com.example.campus.data.repository

import android.util.Log
import com.example.campus.data.api.CampusApi
import com.example.campus.data.model.Announcement
import com.example.campus.data.model.AnnouncementCategory
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay

/** Screens talk to this interface, so swapping mock -> real API never touches the UI code. */
interface AnnouncementRepository {
    suspend fun getAnnouncements(): Result<List<Announcement>>
}

/** Sample data for the prototype while Person 1's API is being finished. */
class MockAnnouncementRepository : AnnouncementRepository {
    override suspend fun getAnnouncements(): Result<List<Announcement>> {
        delay(600) // simulate network latency so the loading state shows in the demo
        val now = System.currentTimeMillis()
        val minute = 60_000L
        val hour = 60 * minute
        val day = 24 * hour
        val list = listOf(
            Announcement("a1", "Registrar", "Exam timetable published", AnnouncementCategory.Academic, now - 2 * hour),
            Announcement("a2", "IT Support", "Portal maintenance Sat 22:00", AnnouncementCategory.Administrative, now - day),
            Announcement("a3", "Library", "Extended study hours", AnnouncementCategory.Administrative, now - 2 * day),
            Announcement(
                "a4", "Campus Security",
                "Power outage on Pretoria Campus. Evening classes have moved online.",
                AnnouncementCategory.Emergency, now - 20 * minute
            )
        )
        Log.d("MockAnnouncementRepo", "Returning ${list.size} mock announcements")
        return Result.success(list)
    }
}

/** Real implementation: calls GET /api/announcements through Retrofit. */
class RemoteAnnouncementRepository(private val api: CampusApi) : AnnouncementRepository {
    override suspend fun getAnnouncements(): Result<List<Announcement>> = try {
        val list = api.getAnnouncements()
        Log.d("RemoteAnnouncementRepo", "Loaded ${list.size} announcements from API")
        Result.success(list)
    } catch (e: CancellationException) {
        throw e // never swallow coroutine cancellation
    } catch (e: Exception) {
        Log.e("RemoteAnnouncementRepo", "Failed to load announcements", e)
        Result.failure(e)
    }
}
