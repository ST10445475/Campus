package com.example.campus.ui.common

import android.view.View
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

/**
 * Keeps a red header below the status bar and content above the navigation bar.
 * The app targets SDK 36 (edge-to-edge), same idea as MainActivity's insets listener.
 */
object InsetsHelper {
    fun applyHeaderInsets(root: View, header: View) {
        val headerTopPadding = header.paddingTop
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(bars.left, 0, bars.right, bars.bottom)
            header.setPadding(
                header.paddingLeft,
                headerTopPadding + bars.top,
                header.paddingRight,
                header.paddingBottom
            )
            insets
        }
    }
}
