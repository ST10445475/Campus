package com.example.campus.data.repository

import android.util.Log
import com.example.campus.data.api.CampusApi
import com.example.campus.data.model.CampusEvent
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import java.util.Calendar

interface EventRepository {
    suspend fun getEvents(): Result<List<CampusEvent>>
}

/** Sample events, always relative to "today" so the demo never looks out of date. */
class MockEventRepository : EventRepository {
    override suspend fun getEvents(): Result<List<CampusEvent>> {
        delay(600) // simulate network latency

        fun at(daysFromNow: Int, hour: Int, minute: Int): Long =
            Calendar.getInstance().apply {
                add(Calendar.DAY_OF_YEAR, daysFromNow)
                set(Calendar.HOUR_OF_DAY, hour)
                set(Calendar.MINUTE, minute)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }.timeInMillis

        val list = listOf(
            // In the past: highlighted on the calendar but hidden from "Upcoming"
            CampusEvent("e0", "Guest lecture: fintech in South Africa", at(-2, 14, 0), "Lecture Hall A"),
            // Today: stays visible all day
            CampusEvent("e5", "Study skills workshop", at(0, 16, 0), "Library seminar room"),
            CampusEvent("e1", "Career Fair", at(3, 9, 0), "Hall B"),
            CampusEvent("e2", "Hackathon Info Session", at(6, 12, 30), "Room 2.14"),
            CampusEvent("e3", "New student orientation", at(10, 10, 0), "Main Auditorium"),
            CampusEvent("e4", "Exam timetable Q&A", at(35, 13, 0), "Online (Teams)")
        )
        Log.d("MockEventRepo", "Returning ${list.size} mock events")
        return Result.success(list)
    }
}

/** Real implementation: GET /api/events through Retrofit. */
class RemoteEventRepository(private val api: CampusApi) : EventRepository {
    override suspend fun getEvents(): Result<List<CampusEvent>> = try {
        val list = api.getEvents()
        Log.d("RemoteEventRepo", "Loaded ${list.size} events from API")
        Result.success(list)
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        Log.e("RemoteEventRepo", "Failed to load events", e)
        Result.failure(e)
    }
}
