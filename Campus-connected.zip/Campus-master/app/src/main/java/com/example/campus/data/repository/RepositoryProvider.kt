package com.example.campus.data.repository

import android.content.Context
import com.example.campus.AppConfig
import com.example.campus.data.api.ApiClient

/** One place that decides mock vs real. Flip AppConfig.USE_MOCK to switch the whole app. */
object RepositoryProvider {

    fun announcements(context: Context): AnnouncementRepository =
        if (AppConfig.USE_MOCK) MockAnnouncementRepository()
        else RemoteAnnouncementRepository(ApiClient.get(context))

    fun events(context: Context): EventRepository =
        if (AppConfig.USE_MOCK) MockEventRepository()
        else RemoteEventRepository(ApiClient.get(context))

    fun devices(context: Context): DeviceRepository =
        if (AppConfig.USE_MOCK) MockDeviceRepository()
        else RemoteDeviceRepository(ApiClient.get(context))
}
