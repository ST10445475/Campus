package com.example.campus.ui.events

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.campus.R
import com.example.campus.data.model.CampusEvent
import java.text.SimpleDateFormat
import java.util.Date

/** Event list under the calendar (ListAdapter + DiffUtil, Android Developers, 2026c). */
class EventAdapter : ListAdapter<CampusEvent, EventAdapter.ViewHolder>(DIFF) {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val date: TextView = view.findViewById(R.id.txtEventDate)
        val title: TextView = view.findViewById(R.id.txtEventTitle)
        val location: TextView = view.findViewById(R.id.txtEventLocation)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_event, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = getItem(position)
        // Use the app's current language (set in Settings) for day and month names
        val locale = holder.itemView.context.resources.configuration.locales[0]
        holder.date.text = SimpleDateFormat("EEE d MMM · HH:mm", locale).format(Date(item.startTime))
        holder.title.text = item.title
        holder.location.text = item.location
    }

    companion object {
        private val DIFF = object : DiffUtil.ItemCallback<CampusEvent>() {
            override fun areItemsTheSame(oldItem: CampusEvent, newItem: CampusEvent) =
                oldItem.eventId == newItem.eventId

            override fun areContentsTheSame(oldItem: CampusEvent, newItem: CampusEvent) =
                oldItem == newItem
        }
    }
}
