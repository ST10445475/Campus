package com.example.campus.logic

import com.example.campus.data.model.CampusEvent
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Calendar

class EventLogicTest {

    private fun at(year: Int, month: Int, day: Int, hour: Int = 12, minute: Int = 0): Long =
        Calendar.getInstance().apply {
            clear()
            set(year, month - 1, day, hour, minute, 0)
        }.timeInMillis

    private fun event(id: String, time: Long) = CampusEvent(id, "Title $id", time, "Hall B")

    @Test
    fun upcoming_hides_events_from_earlier_days() {
        val now = at(2026, 9, 21, 15)
        val events = listOf(event("yesterday", at(2026, 9, 20, 10)), event("tomorrow", at(2026, 9, 22)))
        assertEquals(listOf("tomorrow"), EventLogic.upcoming(events, now).map { it.eventId })
    }

    @Test
    fun upcoming_keeps_todays_events_even_if_the_time_has_passed() {
        val now = at(2026, 9, 21, 15)
        val events = listOf(event("this-morning", at(2026, 9, 21, 8)))
        assertEquals(listOf("this-morning"), EventLogic.upcoming(events, now).map { it.eventId })
    }

    @Test
    fun upcoming_is_sorted_soonest_first() {
        val now = at(2026, 9, 21)
        val events = listOf(
            event("later", at(2026, 9, 30)),
            event("soon", at(2026, 9, 22)),
            event("middle", at(2026, 9, 25))
        )
        assertEquals(listOf("soon", "middle", "later"), EventLogic.upcoming(events, now).map { it.eventId })
    }

    @Test
    fun upcoming_of_an_empty_list_is_empty() {
        assertTrue(EventLogic.upcoming(emptyList(), at(2026, 9, 21)).isEmpty())
    }

    @Test
    fun onDay_returns_only_that_days_events_earliest_first() {
        val events = listOf(
            event("afternoon", at(2026, 9, 24, 14)),
            event("morning", at(2026, 9, 24, 9)),
            event("next-day", at(2026, 9, 25, 9))
        )
        val result = EventLogic.onDay(events, DayKey(2026, 9, 24))
        assertEquals(listOf("morning", "afternoon"), result.map { it.eventId })
    }

    @Test
    fun onDay_with_no_events_is_empty() {
        val events = listOf(event("a", at(2026, 9, 24)))
        assertTrue(EventLogic.onDay(events, DayKey(2026, 9, 1)).isEmpty())
    }

    @Test
    fun daysWithEvents_only_counts_the_shown_month_and_removes_duplicates() {
        val events = listOf(
            event("a", at(2026, 9, 3, 9)),
            event("b", at(2026, 9, 3, 15)),
            event("c", at(2026, 9, 24)),
            event("d", at(2026, 10, 1))
        )
        assertEquals(setOf(3, 24), EventLogic.daysWithEvents(events, MonthRef(2026, 9)))
    }
}
