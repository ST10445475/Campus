package com.example.campus.logic

import com.example.campus.data.model.Announcement
import com.example.campus.data.model.AnnouncementCategory
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AnnouncementLogicTest {

    private fun item(id: String, time: Long, category: AnnouncementCategory = AnnouncementCategory.Academic) =
        Announcement(id, "Registrar", "message", category, time)

    @Test
    fun sortNewestFirst_orders_by_timestamp_descending() {
        val sorted = AnnouncementLogic.sortNewestFirst(listOf(item("old", 100), item("new", 300), item("mid", 200)))
        assertEquals(listOf("new", "mid", "old"), sorted.map { it.announcementId })
    }

    @Test
    fun sortNewestFirst_handles_empty_list() {
        assertTrue(AnnouncementLogic.sortNewestFirst(emptyList()).isEmpty())
    }

    @Test
    fun isEmergency_is_true_only_for_emergency_category() {
        assertTrue(AnnouncementLogic.isEmergency(item("e", 1, AnnouncementCategory.Emergency)))
        assertFalse(AnnouncementLogic.isEmergency(item("a", 1, AnnouncementCategory.Academic)))
        assertFalse(AnnouncementLogic.isEmergency(item("b", 1, AnnouncementCategory.Administrative)))
    }
}
