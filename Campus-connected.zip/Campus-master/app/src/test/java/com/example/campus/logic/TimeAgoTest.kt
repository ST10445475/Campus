package com.example.campus.logic

import org.junit.Assert.assertEquals
import org.junit.Test

class TimeAgoTest {
    private val now = 1_000_000_000_000L
    private val minute = 60_000L
    private val hour = 60 * minute
    private val day = 24 * hour

    @Test
    fun under_a_minute_is_just_now() {
        assertEquals(TimeAgo(AgoUnit.JUST_NOW, 0), TimeAgo.from(now, now - 30_000L))
    }

    @Test
    fun five_minutes() {
        assertEquals(TimeAgo(AgoUnit.MINUTES, 5), TimeAgo.from(now, now - 5 * minute))
    }

    @Test
    fun two_hours() {
        assertEquals(TimeAgo(AgoUnit.HOURS, 2), TimeAgo.from(now, now - 2 * hour))
    }

    @Test
    fun three_days() {
        assertEquals(TimeAgo(AgoUnit.DAYS, 3), TimeAgo.from(now, now - 3 * day))
    }

    @Test
    fun future_timestamp_is_treated_as_just_now() {
        assertEquals(TimeAgo(AgoUnit.JUST_NOW, 0), TimeAgo.from(now, now + 10 * minute))
    }
}
