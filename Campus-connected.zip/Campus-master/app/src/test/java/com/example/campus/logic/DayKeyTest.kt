package com.example.campus.logic

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.TimeZone

class DayKeyTest {

    @Test
    fun compareTo_orders_by_year_then_month_then_day() {
        assertTrue(DayKey(2026, 9, 21) < DayKey(2026, 9, 22))
        assertTrue(DayKey(2026, 9, 30) < DayKey(2026, 10, 1))
        assertTrue(DayKey(2026, 12, 31) < DayKey(2027, 1, 1))
        assertEquals(0, DayKey(2026, 9, 21).compareTo(DayKey(2026, 9, 21)))
    }

    @Test
    fun fromMillis_uses_the_given_time_zone() {
        val utc = TimeZone.getTimeZone("UTC")
        val johannesburg = TimeZone.getTimeZone("Africa/Johannesburg") // UTC+2
        val elevenPmUtc = 23L * 60 * 60 * 1000 // 1970-01-01 23:00 UTC

        assertEquals(DayKey(1970, 1, 1), DayKey.fromMillis(elevenPmUtc, utc))
        // 23:00 UTC is already 01:00 the next day in South Africa
        assertEquals(DayKey(1970, 1, 2), DayKey.fromMillis(elevenPmUtc, johannesburg))
    }

    @Test
    fun monthRef_wraps_over_the_year_boundary() {
        assertEquals(MonthRef(2027, 1), MonthRef(2026, 12).next())
        assertEquals(MonthRef(2025, 12), MonthRef(2026, 1).previous())
        assertEquals(MonthRef(2026, 10), MonthRef(2026, 9).next())
        assertEquals(MonthRef(2026, 8), MonthRef(2026, 9).previous())
    }
}
