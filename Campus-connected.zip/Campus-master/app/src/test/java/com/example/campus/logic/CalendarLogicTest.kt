package com.example.campus.logic

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class CalendarLogicTest {

    @Test
    fun grid_size_is_always_a_multiple_of_seven() {
        for (month in 1..12) {
            val grid = CalendarLogic.buildMonthGrid(MonthRef(2026, month))
            assertEquals("month $month", 0, grid.size % 7)
        }
    }

    @Test
    fun september_2026_starts_on_a_tuesday() {
        // 1 Sept 2026 is a Tuesday, so with a Monday-first grid there is one empty cell first
        val grid = CalendarLogic.buildMonthGrid(MonthRef(2026, 9))
        assertNull(grid[0])
        assertEquals(1, grid[1])
        assertEquals(35, grid.size)
        assertEquals(30, grid.filterNotNull().last())
    }

    @Test
    fun august_2026_starts_on_a_saturday() {
        // 1 Aug 2026 is a Saturday, so five empty cells come first
        val grid = CalendarLogic.buildMonthGrid(MonthRef(2026, 8))
        assertEquals(List(5) { null }, grid.take(5))
        assertEquals(1, grid[5])
        assertEquals(31, grid.filterNotNull().last())
    }

    @Test
    fun february_in_a_leap_year_has_29_days() {
        val grid = CalendarLogic.buildMonthGrid(MonthRef(2028, 2))
        assertEquals(29, grid.filterNotNull().size)
    }

    @Test
    fun february_in_a_normal_year_has_28_days() {
        val grid = CalendarLogic.buildMonthGrid(MonthRef(2027, 2))
        assertEquals(28, grid.filterNotNull().size)
    }

    @Test
    fun day_numbers_run_from_1_without_gaps() {
        val days = CalendarLogic.buildMonthGrid(MonthRef(2026, 9)).filterNotNull()
        assertEquals((1..30).toList(), days)
    }
}
