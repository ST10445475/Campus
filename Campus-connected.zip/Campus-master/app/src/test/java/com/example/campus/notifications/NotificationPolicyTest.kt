package com.example.campus.notifications

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class NotificationPolicyTest {

    private val allOff: (String) -> Boolean = { false }
    private val allOn: (String) -> Boolean = { true }

    @Test
    fun enabled_category_is_delivered() {
        assertTrue(NotificationPolicy.shouldDeliver(NotificationCategory.EVENTS, false, allOn))
    }

    @Test
    fun disabled_category_is_blocked() {
        assertFalse(NotificationPolicy.shouldDeliver(NotificationCategory.EVENTS, false, allOff))
    }

    @Test
    fun emergency_announcement_is_delivered_even_when_toggle_is_off() {
        assertTrue(NotificationPolicy.shouldDeliver(NotificationCategory.ANNOUNCEMENTS, true, allOff))
    }

    @Test
    fun normal_announcement_respects_toggle() {
        assertFalse(NotificationPolicy.shouldDeliver(NotificationCategory.ANNOUNCEMENTS, false, allOff))
    }

    @Test
    fun emergency_flag_on_other_categories_does_not_bypass_toggle() {
        assertFalse(NotificationPolicy.shouldDeliver(NotificationCategory.DISCUSSIONS, true, allOff))
    }

    @Test
    fun policy_reads_the_correct_preference_key() {
        val onlyAnnouncementsOn: (String) -> Boolean = { it == "notif_announcements" }
        assertTrue(NotificationPolicy.shouldDeliver(NotificationCategory.ANNOUNCEMENTS, false, onlyAnnouncementsOn))
        assertFalse(NotificationPolicy.shouldDeliver(NotificationCategory.EVENTS, false, onlyAnnouncementsOn))
    }
}
