package com.example.campus.notifications

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class NotificationCategoryTest {

    @Test
    fun fromFcm_maps_known_values() {
        assertEquals(NotificationCategory.ANNOUNCEMENTS, NotificationCategory.fromFcm("announcements"))
        assertEquals(NotificationCategory.DISCUSSIONS, NotificationCategory.fromFcm("discussions"))
    }

    @Test
    fun fromFcm_returns_null_for_unknown_or_missing_values() {
        assertNull(NotificationCategory.fromFcm("gossip"))
        assertNull(NotificationCategory.fromFcm(null))
    }

    @Test
    fun pref_keys_match_the_keys_saved_by_the_settings_screen() {
        val keys = NotificationCategory.values().map { it.prefKey }.toSet()
        assertEquals(
            setOf("notif_assignments", "notif_timetable", "notif_announcements", "notif_events", "notif_discussions"),
            keys
        )
    }
}
