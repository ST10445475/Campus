package com.example.campus.notifications

import android.Manifest
import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.example.campus.R
import com.example.campus.ui.announcements.AnnouncementsActivity

/**
 * Builds and shows local notifications for pushes received from FCM.
 * Channels and the Android 13+ permission follow Android Developers (2026a, 2026b).
 */
object NotificationHelper {
    private const val TAG = "NotificationHelper"
    const val CHANNEL_GENERAL = "campus_general"
    const val CHANNEL_EMERGENCY = "campus_emergency"

    /** Safe to call repeatedly; Android ignores channels that already exist. */
    fun ensureChannels(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = context.getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(
            NotificationChannel(
                CHANNEL_GENERAL,
                context.getString(R.string.notif_channel_general),
                NotificationManager.IMPORTANCE_DEFAULT
            )
        )
        manager.createNotificationChannel(
            NotificationChannel(
                CHANNEL_EMERGENCY,
                context.getString(R.string.notif_channel_emergency),
                NotificationManager.IMPORTANCE_HIGH
            )
        )
    }

    /**
     * Shows a notification if the policy and permission allow it.
     * @return true if it was shown, false if it was blocked (toggle off / no permission).
     */
    @SuppressLint("MissingPermission") // permission is checked just below
    fun show(
        context: Context,
        category: NotificationCategory,
        title: String,
        body: String,
        isEmergency: Boolean = false
    ): Boolean {
        // Person 2's toggles live in the "settings" SharedPreferences, default = on
        val settings = context.getSharedPreferences("settings", Context.MODE_PRIVATE)
        val allowed = NotificationPolicy.shouldDeliver(category, isEmergency) { key ->
            settings.getBoolean(key, true)
        }
        if (!allowed) {
            Log.d(TAG, "Blocked by student setting: ${category.prefKey}")
            return false
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            Log.w(TAG, "POST_NOTIFICATIONS not granted, cannot show notification")
            return false
        }

        ensureChannels(context)

        val pendingIntent = PendingIntent.getActivity(
            context,
            category.ordinal,
            destinationFor(context, category),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val notification = NotificationCompat.Builder(
            context, if (isEmergency) CHANNEL_EMERGENCY else CHANNEL_GENERAL
        )
            .setSmallIcon(R.drawable.ic_campus_notification)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(if (isEmergency) NotificationCompat.PRIORITY_HIGH else NotificationCompat.PRIORITY_DEFAULT)
            .setColor(ContextCompat.getColor(context, R.color.campus_crimson))
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .build()

        val id = (System.currentTimeMillis() % Int.MAX_VALUE).toInt()
        NotificationManagerCompat.from(context).notify(id, notification)
        Log.d(TAG, "Shown: category=${category.fcmValue}, emergency=$isEmergency")
        return true
    }

    /** Where a tap on the notification should go. Other categories open the app for now. */
    private fun destinationFor(context: Context, category: NotificationCategory): Intent {
        val intent = when (category) {
            NotificationCategory.ANNOUNCEMENTS -> Intent(context, AnnouncementsActivity::class.java)
            else -> context.packageManager.getLaunchIntentForPackage(context.packageName)
                ?: Intent(context, AnnouncementsActivity::class.java)
        }
        return intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
    }
}
