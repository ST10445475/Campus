package com.example.campus

/**
 * Central switches for the campus features (Person 5).
 *
 * USE_MOCK = true  -> screens run on built-in sample data (no server needed).
 * USE_MOCK = false -> screens call Person 1's REST API at BASE_URL.
 */
object AppConfig {
    const val USE_MOCK = true

    // TODO: replace with the Azure App Service URL from Person 1 (must end with "/")
    const val BASE_URL = "https://your-api.azurewebsites.net/"
}
